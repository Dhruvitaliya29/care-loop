"""Secure provider-neutral IMAP and official Telegram Bot API intake adapters."""
import email, imaplib, json, os, ssl, time, urllib.parse, urllib.request
from email.header import decode_header, make_header
from email.utils import parseaddr
from pathlib import Path
from database.db import connect
from services.document_parser import EXTENSIONS, MAX_BYTES
from services.intake import intake_document, health, log, migrate

def _state(name,default='0'):
 with connect() as db:
  row=db.execute('SELECT value FROM integration_state WHERE name=?',(name,)).fetchone()
 return row['value'] if row else default

def _set_state(name,value):
 with connect() as db:
  db.execute('INSERT INTO integration_state(name,value) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET value=excluded.value',(name,str(value)))

def sync_email(limit=100):
 migrate()
 if os.getenv('EMAIL_ENABLED','false').lower() not in ('1','true','yes'):
  health('email','Disabled');return {'status':'Disabled','processed':0}
 host=os.getenv('EMAIL_HOST') or os.getenv('CARELOOP_IMAP_HOST','')
 username=os.getenv('EMAIL_USERNAME') or os.getenv('CARELOOP_IMAP_USER','')
 password=os.getenv('EMAIL_PASSWORD') or os.getenv('CARELOOP_IMAP_PASSWORD','')
 port=int(os.getenv('EMAIL_PORT','993'))
 folder=os.getenv('EMAIL_FOLDER') or os.getenv('CARELOOP_IMAP_FOLDER','INBOX')
 if not all((host,username,password)):
  health('email','Not configured');return {'status':'Not configured','processed':0}
 allowed={s.strip().lower() for s in os.getenv('EMAIL_ALLOWED_SENDERS','').split(',') if s.strip()}
 result={'status':'Connected','processed':0,'pending_review':0,'duplicate':0,'failed':0}
 try:
  with imaplib.IMAP4_SSL(host,port=port,ssl_context=ssl.create_default_context(),timeout=25) as conn:
   conn.login(username,password)
   code,details=conn.select(folder,readonly=True)
   if code!='OK':raise ConnectionError('Folder unavailable')
   uidv=conn.response('UIDVALIDITY')[1]
   validity=uidv[0].decode() if uidv and uidv[0] else 'unknown'
   cursor_name='email_uid:'+username+':'+folder+':'+validity
   cursor=int(_state(cursor_name))
   typ,data=conn.uid('search',None,'UID',f'{cursor+1}:*')
   if typ!='OK':raise ConnectionError('Mailbox search failed')
   uids=[int(x) for x in (data[0] or b'').split() if x.isdigit() and int(x)>cursor]
   for uid in uids[:max(1,min(500,limit))]:
    typ,parts=conn.uid('fetch',str(uid),'(BODY.PEEK[])')
    if typ!='OK':raise ConnectionError('Message fetch failed')
    raw=next((p[1] for p in parts if isinstance(p,tuple) and isinstance(p[1],bytes)),None)
    if raw is None:raise ConnectionError('Empty message response')
    msg=email.message_from_bytes(raw)
    sender=parseaddr(msg.get('From',''))[1].lower()
    if allowed and sender not in allowed:
     log('email',uid,'',None,'Sender authorization','Ignored','Sender not on allowlist')
     _set_state(cursor_name,uid);continue
    subject=str(make_header(decode_header(msg.get('Subject',''))))
    message_id=msg.get('Message-ID') or f'{validity}:{uid}'
    count=0
    for idx,part in enumerate(msg.walk()):
     filename=part.get_filename()
     if not filename:continue
     filename=str(make_header(decode_header(filename)))
     ext=Path(filename).suffix.lower()
     if ext not in EXTENSIONS:
      log('email',f'{validity}:{uid}:{idx}',filename,None,'File validation','Ignored','Unsupported attachment type')
      continue
     count+=1
     payload=part.get_payload(decode=True) or b''
     docid=f'{validity}:{uid}:{idx}:{message_id}'
     outcome=intake_document('email',docid,filename,payload,subject=subject,sender=sender,received_at=msg.get('Date'))
     key=outcome['status']
     result[{'processed':'processed','pending_review':'pending_review','duplicate':'duplicate','failed':'failed'}.get(key,'failed')]+=1
    _set_state(cursor_name,uid)
   health('email','Connected')
  return result
 except Exception as exc:
  health('email','Connection failed',type(exc).__name__)
  log('email','connection','',None,'Connection','Failed',type(exc).__name__)
  return {'status':'Connection failed','processed':result['processed'],'error':type(exc).__name__}

def telegram_request(method,token,fields=None):
 endpoint=f'https://api.telegram.org/bot{token}/{method}'
 data=urllib.parse.urlencode(fields or {}).encode()
 request=urllib.request.Request(endpoint,data=data)
 with urllib.request.urlopen(request,timeout=35) as response: payload=json.load(response)
 if not payload.get('ok'):raise ConnectionError('Telegram returned API error')
 return payload['result']

def sync_laundry(limit=100):
 migrate()
 if os.getenv('TELEGRAM_ENABLED','false').lower() not in ('true','1','yes'):
  health('telegram','Disabled');return {'status':'Disabled','processed':0}
 token=os.getenv('TELEGRAM_BOT_TOKEN') or os.getenv('CARELOOP_TELEGRAM_BOT_TOKEN','')
 allow={s.strip() for s in (os.getenv('TELEGRAM_ALLOWED_CHAT_IDS') or os.getenv('CARELOOP_TELEGRAM_CHAT_ID','')).split(',') if s.strip()}
 if not token or not allow:
  health('telegram','Not configured');return {'status':'Not configured','processed':0}
 stats={'status':'Connected','processed':0,'pending_review':0,'duplicate':0,'failed':0,'unauthorized':0}
 try:
  telegram_request('getMe',token)
  offset=int(_state('telegram_offset'))
  updates=telegram_request('getUpdates',token,{'offset':offset,'limit':max(1,min(limit,100)),'timeout':0})
  for update in updates:
   update_id=int(update['update_id'])
   message=update.get('message') or update.get('channel_post') or {}
   chatid=str(message.get('chat',{}).get('id',''))
   if chatid not in allow:
    stats['unauthorized']+=1
    log('telegram',update_id,'',None,'Authorization','Ignored','Unauthorized chat')
    _set_state('telegram_offset',update_id+1);continue
   document=message.get('document')
   photos=message.get('photo',[])
   attachment=document or (photos[-1] if photos else None)
   if not attachment:
    _set_state('telegram_offset',update_id+1);continue
   name=document.get('file_name',f'linen_{update_id}.pdf') if document else f'linen_photo_{update_id}.jpg'
   # Images/photos are reviewed if content does not establish laundry identity.
   if Path(name).suffix.lower() not in EXTENSIONS:
    log('telegram',update_id,name,'EV-029','File validation','Ignored','Unsupported type')
    _set_state('telegram_offset',update_id+1);continue
   size=int(attachment.get('file_size',0))
   if size>MAX_BYTES:
    log('telegram',update_id,name,'EV-029','File validation','Failed','File exceeds size limit')
    stats['failed']+=1
    _set_state('telegram_offset',update_id+1);continue
   fileinfo=telegram_request('getFile',token,{'file_id':attachment['file_id']})
   url=f'https://api.telegram.org/file/bot{token}/{fileinfo["file_path"]}'
   with urllib.request.urlopen(url,timeout=35) as resp:data=resp.read(MAX_BYTES+1)
   # Telegram source is an authorized laundry-only intake; still subject to full extraction validation.
   outcome=intake_document('telegram',f'{chatid}:{message.get("message_id",update_id)}:{attachment["file_id"]}',name,data,
      subject='Laundry '+(message.get('caption') or ''),sender='telegram_chat_'+chatid,category_hint='EV-029')
   status=outcome['status']
   stats[status if status in stats else 'failed']+=1
   receipt={'processed':'Document imported for Laundry & Linen. Status: Pending verification.',
            'pending_review':'Document saved. Extraction or review is required.',
            'duplicate':'Document already received.',
            'failed':'Document could not be processed. Please contact the administrator.'}.get(status,'Document received.')
   # Reply failures must not replay or duplicate the intake.
   try:telegram_request('sendMessage',token,{'chat_id':chatid,'text':receipt,'reply_to_message_id':message.get('message_id')})
   except Exception:log('telegram',update_id,name,'EV-029','Acknowledgement','Failed','Telegram reply error')
   _set_state('telegram_offset',update_id+1)
  health('telegram','Connected')
  return stats
 except Exception as exc:
  health('telegram','Connection failed',type(exc).__name__)
  log('telegram','connection','',None,'Connection','Failed',type(exc).__name__)
  return {'status':'Connection failed','processed':stats['processed'],'error':type(exc).__name__}
