"""Sixteen concrete workflows: shared persistence, per-category fields and validation."""
from pathlib import Path
from database.db import create_document,save_record,records
from services.document_parser import parse_document
from services.validation import validate
from config.categories import SCHEMAS

def record_key(category, data,doc_id=None,index=0):
    # Stable business key (where possible); identical documents cannot proliferate records.
    special={
    'EV-001':['employee_id','training_topic','training_date'], 'EV-002':['employee_id','registration_number'],
    'EV-008':['capa_id'],'EV-009':['contract_number'],'EV-013':['asset_id','inspection_date'],
    'EV-016':['asset_id','test_date'],'EV-018':['asset_id','service_date'],
    'EV-019':['asset_id','inspection_date'],'EV-020':['asset_id','certificate_number'],
    'EV-022':['service_id'],'EV-023':['asset_id','last_service_date'],'EV-025':['location','date','time'],
    'EV-027':['inspection_id'],'EV-028':['manifest_number'],'EV-029':['batch_id'],'EV-038':['incident_id']}
    fields=special[category]
    values=[str(data.get(f,'')).strip() for f in fields]
    if all(values):return '|'.join(values).lower()
    return f'file-{doc_id}-row-{index}'

def process_bytes(category,filename,content,source='upload'):
    # Parse first, then persist: rejected files do not enter evidence storage.
    items=parse_document(filename,content,category)
    doc_id=create_document(category,filename,content,source)
    output=[]
    existing={r['record_key']:r for r in records(category)}
    seen=set()
    for idx,data in enumerate(items):
        key=record_key(category,data,doc_id,idx)
        status,issues=validate(category,data)
        if key in seen:issues.append('Duplicate record key inside uploaded document');status='Duplicate'
        elif key in existing and existing[key]['document_id']!=doc_id:
            # Retain the original record and source association; do not overwrite an approved record.
            output.append({'id':existing[key]['id'],'key':key,'status':'Duplicate','issues':['Business key already exists in another source document'],'data':data})
            seen.add(key)
            continue
        seen.add(key)
        rid=save_record(category,key,data,status,issues,doc_id)
        output.append({'id':rid,'key':key,'status':status,'issues':issues,'data':data})
    return output

def process_sample(category):
    from sample_data.seed import sample_path
    p=sample_path(category)
    return process_bytes(category,p.name,p.read_bytes(),'demo')
