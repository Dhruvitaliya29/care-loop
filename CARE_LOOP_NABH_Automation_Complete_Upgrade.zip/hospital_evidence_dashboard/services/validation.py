"""Real deterministic per-category validation; no compliance certification."""
from datetime import datetime, date, timedelta
from config.categories import SCHEMAS,DATE_FIELDS
from database.db import master

def parse_date(v):
    if not v:return None
    for fmt in ('%d-%m-%Y','%Y-%m-%d','%d/%m/%Y','%Y-%m-%d %H:%M:%S'):
        try:return datetime.strptime(str(v).strip(),fmt).date()
        except ValueError:pass
    return None

def validate(category,data,today=None):
    today=today or date.today(); issues=[]
    for field in SCHEMAS[category]:
        if not str(data.get(field,'')).strip():
            # Some issued licences legitimately have no expiry. Missing expiry flagged for review only.
            if category=='EV-002' and field=='expiry_date':issues.append('Expiry unspecified – verify with issuing council (no universal expiry assumed)')
            elif category=='EV-008' and field=='effectiveness_status':issues.append('Effectiveness check pending human verification')
            else: issues.append(f'Missing: {field.replace("_"," ")}')
    for f in DATE_FIELDS & set(data):
        if data.get(f) and parse_date(data[f]) is None:issues.append(f'Invalid date: {f}')
    staff={x['id'] for x in master('staff')}; assets={x['id'] for x in master('assets')}; vendors={x['id'] for x in master('vendors')}
    if data.get('employee_id') and data['employee_id'] not in staff:issues.append('Staff master mismatch')
    if data.get('asset_id') and data['asset_id'] not in assets:issues.append('Asset master mismatch')
    if data.get('vendor_id') and data['vendor_id'] not in vendors:issues.append('Vendor master mismatch')
    expiry_fields={'EV-002':'expiry_date','EV-009':'end_date','EV-020':'valid_until'}
    sched_fields={'EV-008':'due_date','EV-013':'next_due_date','EV-016':'next_due_date','EV-018':'next_due_date','EV-019':'next_due_date','EV-022':'next_visit','EV-023':'next_due_date'}
    exp=parse_date(data.get(expiry_fields.get(category,'')))
    due=parse_date(data.get(sched_fields.get(category,'')))
    if exp and exp<today:issues.append('Document or contract expired on '+exp.strftime('%d-%m-%Y'))
    if due and due<today:issues.append('Scheduled activity overdue since '+due.strftime('%d-%m-%Y'))
    if category=='EV-001' and str(data.get('competency_status','')).lower() not in ('assessed','passed'):
        issues.append('Competency not independently verified')
    if category=='EV-008' and str(data.get('effectiveness_status','')).lower()!='verified':issues.append('CAPA effectiveness requires reviewer assessment')
    if category=='EV-013':
        for field in ('pressure_status','seal_status'):
            if data.get(field,'').lower() not in ('ok','pass','satisfactory'):issues.append(f'Fire extinguisher {field} requires attention')
    if category=='EV-016' and (str(data.get('detector_test','')).lower()!='pass' or str(data.get('call_point_test','')).lower()!='pass'):issues.append('Fire alarm functional test finding')
    if category=='EV-018':
        try:
            hz=float(data.get('frequency_hz',''))
            if not 49<=hz<=51:issues.append('Generator frequency outside POC-configured 49–51 Hz review band')
        except ValueError:pass
    if category=='EV-019' and str(data.get('alarm_result','')).lower()!='pass':issues.append('Medical gas alarm inspection requires review')
    if category=='EV-023':
        last=parse_date(data.get('last_service_date'))
        try:interval=int(data.get('frequency_days',''))
        except ValueError:interval=0
        if last and interval>0:
            actual=(last+timedelta(days=interval)).strftime('%d-%m-%Y')
            if data.get('next_due_date') and actual!=data['next_due_date']:issues.append('Maintenance due-date does not match last service + configured frequency')
        elif interval<=0:issues.append('Maintenance frequency must be a positive number')
    if category=='EV-025' and str(data.get('completion_status','')).lower()!='completed':issues.append('Cleaning activity incomplete; quality remains unverified')
    if category=='EV-027':
        for f in ('yellow_check','red_check','white_check','blue_check'):
            if str(data.get(f,'')).lower()!='pass':issues.append(f'Waste segregation check failed: {f}')
    if category=='EV-028':
        try:
            weight=float(data.get('weight_kg',''))
            if weight<0:issues.append('Invalid negative collection weight')
            expected=data.get('expected_weight_kg')
            if expected and abs(weight-float(expected))>0.1:issues.append('Manifest weight differs from expected pickup weight (POC tolerance 0.1 kg)')
        except ValueError:issues.append('Invalid collection weight')
    if category=='EV-029':
        try:
            if int(data.get('sent_qty',''))!=int(data.get('returned_qty','')):issues.append('Linen quantity discrepancy')
        except ValueError:issues.append('Invalid linen quantity')
    if category=='EV-038' and data.get('investigation_status','').lower()!='closed':issues.append('Incident investigation remains open')
    if not issues: status='Checks Passed'
    elif any('expired' in i.lower() for i in issues): status='Expired'
    elif any('overdue' in i.lower() for i in issues): status='Overdue'
    elif any('missing' in i.lower() or 'unspecified' in i.lower() for i in issues):status='Missing Information'
    else:status='Action Required'
    return status,issues
