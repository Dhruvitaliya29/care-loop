"""Shared, persistent inbound attachment pipeline for manual upload, IMAP and Telegram."""
import hashlib, json, mimetypes, os, re, sqlite3
from datetime import datetime, timezone
from pathlib import Path
from database.db import connect, DATA_DIR
from services.document_parser import EXTENSIONS, MAX_BYTES
from services.workflows import process_bytes
from config.categories import CAT

ROOT=DATA_DIR/'intake_originals'
ROOT.mkdir(parents=True,exist_ok=True)

MIGRATION='''
CREATE TABLE IF NOT EXISTS intake_jobs (
 id INTEGER PRIMARY KEY, source TEXT NOT NULL, source_id TEXT NOT NULL,
 filename TEXT NOT NULL, sender TEXT, subject TEXT, received_at TEXT,
 content_sha256 TEXT NOT NULL, stored_path TEXT NOT NULL,
 category_id TEXT, confidence REAL DEFAULT 0, status TEXT NOT NULL,
 record_ids TEXT DEFAULT '[]', duplicate_of INTEGER, error TEXT,
 attempts INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(source,source_id)
);
CREATE INDEX IF NOT EXISTS intake_sha_idx ON intake_jobs(content_sha256);
CREATE INDEX IF NOT EXISTS intake_status_idx ON intake_jobs(status);
CREATE TABLE IF NOT EXISTS integration_logs (
 id INTEGER PRIMARY KEY, integration TEXT NOT NULL, source_id TEXT, filename TEXT,
 category_id TEXT, stage TEXT, status TEXT, detail TEXT, attempts INTEGER DEFAULT 0,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS integration_health (
 name TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'Not configured',
 last_checked TEXT, last_success TEXT, last_error TEXT
);
CREATE TABLE IF NOT EXISTS intake_notifications (
 id INTEGER PRIMARY KEY, intake_id INTEGER, kind TEXT, message TEXT NOT NULL,
 is_read INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(intake_id) REFERENCES intake_jobs(id)
);
CREATE TABLE IF NOT EXISTS integration_state(name TEXT PRIMARY KEY,value TEXT);
'''

def migrate():
 with connect() as db:
  db.execute('PRAGMA journal_mode=WAL')
  db.executescript(MIGRATION)

def log(source, source_id, filename, category, stage, status, detail='', attempts=0):
 with connect() as db:
  db.execute('INSERT INTO integration_logs(integration,source_id,filename,category_id,stage,status,detail,attempts) VALUES(?,?,?,?,?,?,?,?)',
             (source,str(source_id),filename,category,stage,status,str(detail)[:240],attempts))

def health(name,status,error=''):
 now=datetime.now(timezone.utc).isoformat(timespec='seconds')
 with connect() as db:
  db.execute('''INSERT INTO integration_health(name,status,last_checked,last_success,last_error) VALUES(?,?,?,?,?)
   ON CONFLICT(name) DO UPDATE SET status=excluded.status,last_checked=excluded.last_checked,
   last_success=CASE WHEN excluded.status='Connected' THEN excluded.last_success ELSE integration_health.last_success END,
   last_error=excluded.last_error''',(name,status,now,now if status=='Connected' else None,error[:160]))

def _inspect(filename,content):
 suffix=Path(filename).suffix.lower()
 if suffix not in EXTENSIONS:raise ValueError('Unsupported extension')
 if not content:raise ValueError('Empty attachment')
 if len(content)>MAX_BYTES:raise ValueError('Attachment exceeds size limit')
 starts={'.pdf':content.startswith(b'%PDF-'),'.xlsx':content.startswith(b'PK\x03\x04'),
 '.docx':content.startswith(b'PK\x03\x04'),'.png':content.startswith(b'\x89PNG\r\n\x1a\n'),
 '.jpg':content.startswith(b'\xff\xd8'),'.jpeg':content.startswith(b'\xff\xd8')}
 if suffix in starts and not starts[suffix]:raise ValueError('File signature does not match extension')
 if suffix=='.csv':
  if b'\x00' in content[:4096]:raise ValueError('CSV contains binary data')
  try:content.decode('utf-8-sig')
  except UnicodeDecodeError:raise ValueError('CSV must be UTF-8')
 if suffix in ('.docx','.xlsx'):
  import zipfile,io
  try:
   with zipfile.ZipFile(io.BytesIO(content)) as z:
    names=set(z.namelist())
    if len(names)>3000 or sum(i.file_size for i in z.infolist())>100*1024*1024:
     raise ValueError('Archive exceeds safe uncompressed size')
    required='word/document.xml' if suffix=='.docx' else 'xl/workbook.xml'
    if required not in names:raise ValueError('Office document structure invalid')
  except zipfile.BadZipFile:raise ValueError('Corrupted Office document')
 return suffix

def safe_filename(value):
 name=Path(str(value).replace('\\','/')).name
 return re.sub(r'[^a-zA-Z0-9._-]','_',name)[:100] or 'attachment'

def _notify(job,kind,message):
 with connect() as db:
  db.execute('INSERT INTO intake_notifications(intake_id,kind,message) VALUES(?,?,?)',(job,kind,message[:240]))

def intake_document(source,source_id,filename,content,subject='',sender='',text='',category_hint=None,received_at=None):
 """Immutable originals, durable status, cross-source content dedupe; never silently discard failures."""
 migrate()
 source=str(source).lower();source_id=str(source_id)
 if source not in ('manual','email','telegram','retry'):raise ValueError('Unknown source')
 if not isinstance(content,bytes):raise TypeError('Content must be bytes')
 digest=hashlib.sha256(content).hexdigest()
 name=safe_filename(filename)
 stored=ROOT / f'{digest}_{name}'
 # Preserve even malformed supported attachments for inspection/retry, subject to size cap.
 if len(content)>MAX_BYTES:raise ValueError('Attachment exceeds size limit')
 if content and not stored.exists():stored.write_bytes(content)
 with connect() as db:
  old=db.execute('SELECT id,category_id,status FROM intake_jobs WHERE source=? AND source_id=?',(source,source_id)).fetchone()
  if old:return {'status':'duplicate','category':old['category_id'],'intake_id':old['id']}
  duplicate=db.execute("SELECT id,category_id FROM intake_jobs WHERE content_sha256=? AND status='Imported' ORDER BY id LIMIT 1",(digest,)).fetchone()
  if not duplicate:
   # Dedupe against previously uploaded evidence, including manual uploads before migration.
   duplicate=db.execute('SELECT id,category_id FROM documents WHERE sha256=? LIMIT 1',(digest,)).fetchone()
  db.execute('''INSERT INTO intake_jobs(source,source_id,filename,sender,subject,received_at,content_sha256,stored_path,status,duplicate_of)
   VALUES(?,?,?,?,?,?,?,?,?,?)''',(source,source_id,name,sender[:200],subject[:200],received_at or datetime.now(timezone.utc).isoformat(),digest,str(stored),'Duplicate' if duplicate else 'Received',duplicate['id'] if duplicate else None))
  jid=db.execute('SELECT last_insert_rowid()').fetchone()[0]
 if duplicate:
  log(source,source_id,name,duplicate['category_id'],'Deduplication','Duplicate','Exact content already imported')
  _notify(jid,'duplicate','Duplicate document received: '+name)
  return {'status':'duplicate','category':duplicate['category_id'],'intake_id':jid}
 try:
  _inspect(name,content)
 except Exception as e:
  with connect() as db:db.execute('UPDATE intake_jobs SET status=?,error=? WHERE id=?',('Failed',str(e)[:180],jid))
  log(source,source_id,name,None,'File validation','Failed',str(e))
  _notify(jid,'failure','Attachment could not be processed: '+name)
  return {'status':'failed','category':None,'intake_id':jid,'error':str(e)}
 return process_job(jid,text=text,category_hint=category_hint)

def _classification_text(filename,data):
 """Extract a bounded classification hint, without inventing evidence fields."""
 suffix=Path(filename).suffix.lower()
 try:
  if suffix=='.pdf':
   import fitz
   with fitz.open(stream=data,filetype='pdf') as pdf:
    return '\n'.join(page.get_text() for page in list(pdf)[:4])[:16000]
  if suffix=='.docx':
   from docx import Document
   import io
   d=Document(io.BytesIO(data))
   return '\n'.join([p.text for p in d.paragraphs]+[c.text for t in d.tables for r in t.rows for c in r.cells])[:16000]
  if suffix in ('.csv','.xlsx'):
   import pandas as pd,io
   frame=(pd.read_csv(io.BytesIO(data),nrows=5) if suffix=='.csv' else pd.read_excel(io.BytesIO(data),nrows=5))
   return ' '.join(map(str,frame.columns))+' '+frame.to_string(index=False)[:12000]
  if suffix in ('.png','.jpg','.jpeg'):
   from PIL import Image
   import pytesseract,io
   return pytesseract.image_to_string(Image.open(io.BytesIO(data)))[:12000]
 except Exception:
  return ''
 return ''

def process_job(job_id,text='',category_hint=None):
 """Repeatable staged processing with explicit category reassignment. Originals always retained."""
 from services.integrations import classify_confidence
 with connect() as db:
  job=db.execute('SELECT * FROM intake_jobs WHERE id=?',(job_id,)).fetchone()
  if not job:raise ValueError('Intake job not found')
  if job['status'] in ('Imported','Duplicate'):return {'status':'duplicate','category':job['category_id'],'intake_id':job_id}
  attempts=job['attempts']+1
  db.execute("UPDATE intake_jobs SET status='Processing',attempts=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(attempts,job_id))
 category,confidence,reason=classify_confidence(job['subject'] or '',job['filename'],text or _classification_text(job['filename'],Path(job['stored_path']).read_bytes()),job['sender'] or '')
 if category_hint:
  if category_hint not in CAT:raise ValueError('Unrecognized evidence category')
  category,confidence,reason=category_hint,1.0,'Explicit reviewer assignment'
 if confidence<0.72 or not category:
  with connect() as db:
   db.execute("UPDATE intake_jobs SET status='Pending Review',category_id=?,confidence=?,error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",(category,confidence,reason[:180],job_id))
  log(job['source'],job['source_id'],job['filename'],category,'Classification','Pending Review',reason,attempts)
  _notify(job_id,'review','Classification review required: '+job['filename'])
  return {'status':'pending_review','category':category,'intake_id':job_id,'confidence':confidence}
 try:
  data=Path(job['stored_path']).read_bytes()
  result=process_bytes(category,job['filename'],data,job['source'])
  ids=[x['id'] for x in result]
  with connect() as db:
   db.execute('''UPDATE intake_jobs SET status='Imported',category_id=?,confidence=?,record_ids=?,error=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?''',(category,confidence,json.dumps(ids),job_id))
  log(job['source'],job['source_id'],job['filename'],category,'Extraction and validation','Imported',f'{len(ids)} records',attempts)
  _notify(job_id,'received','Document imported for '+category+': '+job['filename'])
  return {'status':'processed','category':category,'records':len(ids),'intake_id':job_id,'record_ids':ids}
 except Exception as exc:
  # Do not print raw document contents or secrets in errors.
  detail=type(exc).__name__+': '+str(exc)[:120]
  with connect() as db:
   db.execute('''UPDATE intake_jobs SET status='Pending Review',category_id=?,confidence=?,error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?''',(category,confidence,detail,job_id))
  log(job['source'],job['source_id'],job['filename'],category,'Extraction','Failed',type(exc).__name__,attempts)
  _notify(job_id,'failure','Document extraction needs review: '+job['filename'])
  return {'status':'pending_review','category':category,'intake_id':job_id,'error':detail}
