from io import BytesIO
import csv,io
import pandas as pd
from database.db import records
from config.categories import LABEL

def report_frame(category):
    rows=records(category)
    return pd.DataFrame([{'record_id':r['id'],'evidence_id':r['category_id'],**r['data'],'validation_status':r['validation_status'],'review_status':r['review_status'],'source_file':r['source_filename'],'exceptions':' | '.join(r['issues'])} for r in rows])

def csv_bytes(category):
    df=report_frame(category)
    buf=io.StringIO();buf.write(LABEL+'\n');df.to_csv(buf,index=False);return buf.getvalue().encode('utf-8-sig')

def excel_bytes(category):
    df=report_frame(category)
    buf=BytesIO()
    with pd.ExcelWriter(buf,engine='xlsxwriter') as writer:
        df.to_excel(writer,sheet_name='Evidence Register',startrow=2,index=False)
        ws=writer.sheets['Evidence Register'];ws.write(0,0,LABEL);ws.freeze_panes(3,0)
        ws.set_column(0,max(len(df.columns)-1,0),19)
    return buf.getvalue()
