"""Document extraction shared by generated samples and uploaded user files."""
from pathlib import Path
from io import BytesIO
import csv, re
import pandas as pd
from config.categories import SCHEMAS
MAX_BYTES=12*1024*1024
EXTENSIONS={'.pdf','.csv','.xlsx','.docx','.jpg','.jpeg','.png'}

def parse_document(filename, content, category):
    ext=Path(filename).suffix.lower()
    if ext not in EXTENSIONS: raise ValueError('Unsupported file type')
    if not content or len(content)>MAX_BYTES:raise ValueError('File empty or exceeds 12 MB')
    if ext=='.pdf':
        import fitz
        with fitz.open(stream=content,filetype='pdf') as doc:
            text='\n'.join(p.get_text() for p in doc)
        if not text.strip():
            try:
                import pytesseract
                from PIL import Image
                with fitz.open(stream=content,filetype='pdf') as scanned:
                    chunks=[]
                    for page in list(scanned)[:10]:
                        pix=page.get_pixmap(matrix=fitz.Matrix(2,2))
                        image=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
                        chunks.append(pytesseract.image_to_string(image))
                    text='\n'.join(chunks)
            except Exception as exc: raise ValueError('Scanned PDF requires optional Tesseract OCR. '+str(exc))
        return _text_records(text,category)
    if ext=='.docx':
        from docx import Document
        doc=Document(BytesIO(content))
        text='\n'.join(p.text for p in doc.paragraphs)
        for table in doc.tables:
            text+='\n'+'\n'.join(' | '.join(c.text for c in row.cells) for row in table.rows)
        return _text_records(text,category)
    if ext in ('.jpg','.jpeg','.png'):
        try:
            from PIL import Image
            import pytesseract
            text=pytesseract.image_to_string(Image.open(BytesIO(content)))
        except Exception as exc:
            raise ValueError('Image OCR requires optional Tesseract OCR installed on this computer. '+str(exc))
        return _text_records(text,category)
    if ext=='.csv':
        df=pd.read_csv(BytesIO(content),dtype=str,keep_default_na=False)
    else:
        df=pd.read_excel(BytesIO(content),dtype=str,keep_default_na=False)
    df.columns=[str(c).strip().lower().replace(' ','_') for c in df.columns]
    allowed=set(SCHEMAS[category])|{'record_id','employee_id','asset_id','vendor_id','capa_id','notes','source_evidence_id','expected_weight_kg','verified_by','signature','status','location','department','certificate_number'}
    fields=[c for c in df.columns if c in allowed]
    if not fields:raise ValueError('No recognised column headers; use the sample template column names')
    return [{k:str(v).strip() for k,v in row.items() if k in allowed} for row in df.fillna('').to_dict('records') if any(str(v).strip() for v in row.values())]

def _text_records(text,category):
    pairs={}
    # Captures labelled lines, tolerates spaces or underscores in labels.
    for line in text.splitlines():
        m=re.match(r'^\s*([A-Za-z][A-Za-z0-9 _/-]{1,48})\s*:\s*(.*?)\s*$',line)
        if m:
            key=re.sub(r'[^a-z0-9]+','_',m.group(1).strip().lower()).strip('_')
            pairs[key]=m.group(2).strip()
    allowed=set(SCHEMAS[category])|{'record_id','notes','expected_weight_kg','status','source_evidence_id','vendor_id','employee_id','asset_id','capa_id','department','location'}
    extracted={k:v for k,v in pairs.items() if k in allowed}
    if not extracted:raise ValueError('No recognised labelled fields found in document. Please use Field: Value labels.')
    return [extracted]
