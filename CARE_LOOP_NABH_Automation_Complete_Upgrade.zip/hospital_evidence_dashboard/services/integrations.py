"""CARE LOOP inbound adapters. No secrets or network activity at import time."""
import os, re, json, io, imaplib, email, hashlib, urllib.request, urllib.parse, datetime
from pathlib import Path
from email.header import decode_header, make_header
from database.db import connect,DATA_DIR
from services.workflows import process_bytes
from services.document_parser import EXTENSIONS,MAX_BYTES

# These routes are configurable. Workbook uses email/folder for staff documents,
# maintenance/vendor evidence and fire certificates, NOT blanket email for all modules.
ROUTES={
 'EV-001':('training','attendance','staff training','training certificate'),
 'EV-002':('professional license','professional licence','registration certificate','qualification','nursing council'),
 'EV-008':('capa','corrective action','preventive action'),
 'EV-009':('vendor agreement','amc contract','maintenance contract'),
 'EV-013':('fire extinguisher','extinguisher inspection'),
 'EV-016':('fire alarm','alarm test'),
 'EV-018':('generator maintenance','dg set','diesel generator'),
 'EV-019':('medical gas','oxygen manifold','mgps'),
 'EV-020':('lift certificate','lift inspection'),
 'EV-022':('pest control','pest-control'),
 'EV-023':('preventive maintenance','pm schedule'),
 'EV-027':('waste segregation','biomedical waste segregation'),
 'EV-028':('waste collection manifest','cbwtf manifest','biomedical waste manifest'),
 'EV-029':('laundry','linen','delivery challan'),
}

def init_integrations():
 with connect() as db:
  db.executescript('''
  CREATE TABLE IF NOT EXISTS inbound_messages(id INTEGER PRIMARY KEY,source TEXT NOT NULL,source_id TEXT NOT NULL, sender TEXT,subject TEXT,received_at TEXT,category_id TEXT,status TEXT NOT NULL,error TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,UNIQUE(source,source_id));
  CREATE TABLE IF NOT EXISTS cleaning_events(id INTEGER PRIMARY KEY,event_id TEXT NOT NULL UNIQUE,event_time TEXT,location TEXT,camera_id TEXT,detected_status TEXT,confidence REAL,evidence_ref TEXT,alert TEXT,verified_by TEXT,review_status TEXT DEFAULT 'Pending Review',raw_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS inbound_attachments(source TEXT NOT NULL,source_id TEXT NOT NULL,filename TEXT NOT NULL,stored_path TEXT NOT NULL,PRIMARY KEY(source,source_id));
  CREATE TABLE IF NOT EXISTS fall_incidents(id INTEGER PRIMARY KEY,incident_id TEXT NOT NULL UNIQUE,incident_at TEXT NOT NULL,location TEXT NOT NULL,anonymous_patient_ref TEXT,description TEXT NOT NULL,severity TEXT,injury TEXT,immediate_action TEXT,witness_staff TEXT,contributing_factors TEXT,investigation TEXT,capa TEXT,follow_up TEXT,status TEXT DEFAULT 'Open',reviewer TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
  ''')

def classify(subject,filename='',text='',sender='',routes=None):
 routes=routes or ROUTES
 hay=' '.join((subject,filename,text[:15000],sender)).lower()
 scores={k:sum(1 for word in words if word in hay) for k,words in routes.items()}
 top=max(scores.values(),default=0)
 winners=[k for k,v in scores.items() if v==top and v>0]
 return (winners[0], 'matched') if len(winners)==1 else (None,'ambiguous' if winners else 'unclassified')

def register_message(source,source_id,sender,subject,category,status,error=''):
 with connect() as db:
  cur=db.execute('INSERT OR IGNORE INTO inbound_messages(source,source_id,sender,subject,category_id,status,error) VALUES(?,?,?,?,?,?,?)',(source,str(source_id),sender,subject,category,status,error[:300]))
  return bool(cur.rowcount)

def ingest_attachment(source,message_id,filename,data,subject='',sender='',text=''):
 # Deduplicate at source-message-attachment level; do not trust attachment filename as an ID.
 digest=hashlib.sha256(data).hexdigest()
 token=f'{message_id}:{digest}'
 with connect() as db:
  exists=db.execute('SELECT id FROM inbound_messages WHERE source=? AND source_id=?',(source,token)).fetchone()
 if exists:return {'status':'duplicate','category':None}
 suffix=Path(filename).suffix.lower()
 if suffix not in EXTENSIONS or not data or len(data)>MAX_BYTES:
  register_message(source,token,sender,subject,None,'Rejected','Unsupported or oversized attachment')
  return {'status':'rejected','category':None}
 category,reason=classify(subject,filename,text,sender)
 if not category:
  register_message(source,token,sender,subject,None,'Pending Classification',reason)
  staging=DATA_DIR/'staged_attachments';staging.mkdir(parents=True,exist_ok=True)
  safe_name=digest+'_'+Path(filename).name.replace('/','_').replace('\\','_')[:110]
  path=staging/safe_name
  if not path.exists():path.write_bytes(data)
  with connect() as db:db.execute('INSERT OR IGNORE INTO inbound_attachments(source,source_id,filename,stored_path) VALUES(?,?,?,?)',(source,token,filename,str(path)))
  return {'status':'pending_review','category':None}
 try:
  rows=process_bytes(category,filename,data,source)
  register_message(source,token,sender,subject,category,'Processed')
  return {'status':'processed','category':category,'records':len(rows)}
 except Exception as exc:
  register_message(source,token,sender,subject,category,'Processing Failed',type(exc).__name__+': '+str(exc))
  return {'status':'failed','category':category}

def classify_confidence(subject,filename='',text='',sender=''):
 """Multi-signal keyword classification; ambiguous hits always require review."""
 signals=[(subject,3),(filename,2),(text[:16000],1)]
 scores={}
 for key,phrases in ROUTES.items():
  scores[key]=sum(weight for content,weight in signals for term in phrases if term in str(content).lower())
 ordered=sorted(scores.items(),key=lambda t:t[1],reverse=True)
 if not ordered or ordered[0][1]==0:return None,0.0,'No matching document classification signals'
 winner,top=ordered[0];runner=ordered[1][1] if len(ordered)>1 else 0
 if runner==top:return None,0.0,'Conflicting evidence category matches'
 confidence=min(0.99,0.45+0.11*top+0.055*max(0,top-runner))
 return winner,confidence,'Matched configured category keywords'

def sync_imap(limit=100):
 from services.connectors import sync_email
 return sync_email(limit)

def sync_telegram(limit=100):
 from services.connectors import sync_laundry
 return sync_laundry(limit)

def ingest_attachment(source,message_id,filename,data,subject='',sender='',text=''):
 from services.intake import intake_document
 source={'test-email':'email'}.get(source,source)
 return intake_document(source,str(message_id)+':'+hashlib.sha256(data).hexdigest(),filename,data,subject,sender,text)

def ingest_cleaning_event(event):
 required=('event_id','timestamp','location','status')
 missing=[f for f in required if not event.get(f)]
 if missing:raise ValueError('Missing cleaning event fields: '+', '.join(missing))
 confidence=event.get('confidence')
 if confidence not in (None,''):
  confidence=float(confidence)
  if not 0<=confidence<=1:raise ValueError('Confidence must be 0..1')
 with connect() as db:
  cur=db.execute('''INSERT OR IGNORE INTO cleaning_events(event_id,event_time,location,camera_id,detected_status,confidence,evidence_ref,alert,verified_by,raw_json) VALUES(?,?,?,?,?,?,?,?,?,?)''',(str(event['event_id']),str(event['timestamp']),str(event['location']),str(event.get('camera_id','')),str(event['status']),confidence,str(event.get('screenshot','')),str(event.get('alert','')),str(event.get('verified_by','')),json.dumps(event)))
  return bool(cur.rowcount)

def ingest_cleaning_json(raw):
 data=json.loads(raw) if isinstance(raw,(str,bytes)) else raw
 events=data if isinstance(data,list) else [data]
 return {'added':sum(ingest_cleaning_event(e) for e in events),'total':len(events)}


def route_pending(message_id,category):
 if category not in ROUTES and category not in ('EV-025','EV-038'):
  raise ValueError('Unknown category')
 with connect() as db:
  row=db.execute("SELECT i.source,i.source_id,i.sender,i.subject,a.filename,a.stored_path FROM inbound_messages i JOIN inbound_attachments a ON a.source=i.source AND a.source_id=i.source_id WHERE i.id=? AND i.status='Pending Classification'",(message_id,)).fetchone()
 if not row:raise ValueError('Pending attachment not found')
 source=Path(row['stored_path'])
 if not source.is_file():raise ValueError('Staged attachment missing')
 result=process_bytes(category,row['filename'],source.read_bytes(),row['source'])
 with connect() as db:db.execute("UPDATE inbound_messages SET category_id=?,status='Processed',error='' WHERE id=?",(category,message_id))
 return len(result)
