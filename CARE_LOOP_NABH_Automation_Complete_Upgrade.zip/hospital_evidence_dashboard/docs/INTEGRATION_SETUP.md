# CARE LOOP: Integration configuration and deployment

## What is verified

The bundled tests exercise the shared intake engine and mocks for IMAP and Telegram. They do **not** verify access to the mailbox, a live bot, or Render. No external integration is marked Connected before a successful protocol call. `integration_health` distinguishes Disabled, Not configured, Connected and Connection failed; its last-success timestamp is retained for audit.

## Local install

Use Python 3.11+:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Run the poller in another terminal after setting secrets:

```powershell
.\.venv\Scripts\python.exe automation_worker.py
```

Set environment variables in Windows user settings or a process-specific secure secret manager. The `.env.example` is documentation only; it is not automatically loaded.

## Email evidence collection

1. Confirm the mail provider, exact IMAP server/port, and whether password-based/app-password IMAP is supported. The address alone does not identify the provider.
2. Obtain explicit permission to read the mailbox. Where a provider mandates OAuth, use its supported OAuth integration instead; this release's generic IMAP connector does not implement an interactive OAuth consent flow.
3. Set `EMAIL_ENABLED=true`, `EMAIL_HOST`, `EMAIL_PORT=993`, `EMAIL_USERNAME`, `EMAIL_PASSWORD` and `EMAIL_FOLDER`. Optionally set `EMAIL_ALLOWED_SENDERS` to a comma-separated strict allowlist.
4. In Automation Centre click **Sync email**, check processing logs and any pending classification items. All IMAP messages are opened read-only and are not sent, deleted, or marked as seen.
5. Run `automation_worker.py` in a separate persistent worker process to poll automatically.

UIDVALIDITY plus UID checkpoint stores progress per mailbox/folder in SQLite. Attachment identity and SHA-256 protect against duplicate imports. Unrecognized or corrupted attachments are stored, classified as pending or failed, and logged. Incoming content is never assumed to be a verified clinical record.

## Telegram laundry automation

1. Create a bot with Telegram BotFather, and copy the token into a secret manager as `TELEGRAM_BOT_TOKEN`.
2. Add the bot to an approved laundry documentation chat. Configure permissions and bot privacy so it can actually receive the intended documents.
3. Find the numeric chat ID and set `TELEGRAM_ALLOWED_CHAT_IDS` (comma-separated). Set `TELEGRAM_ENABLED=true`.
4. Ensure **no webhook** is configured for that bot while using `getUpdates` polling. Only one worker may poll the bot at a time.
5. In Automation Centre click **Sync Telegram** to verify credentials/chat access, then test with a PDF/photo/XLSX receipt. Check `intake_jobs`, `integration_logs` and EV-029 records.
6. The bot replies with the actual intake status (imported, pending review, duplicate or failed). Incoming attachments from unapproved chats are ignored and logged without downloading.

Telegram documents are forced into the existing EV-029 workflow only after chat authorization. Field validation is not bypassed; human verification is required.

## Shared processing and audit

The shared service `services/intake.py` accepts manual, email and Telegram sources. It checks type, size and file signatures, preserves original bytes under `CARELOOP_DATA_DIR/intake_originals`, performs classification (unless an authorized module/human designation is supplied), invokes the existing `process_bytes` parser/validator, persists evidence, and creates log, review or notification entries. Identical files from different channels are deduplicated by SHA-256. Business-key duplicates are handled by existing evidence validation logic. Do not rely on an attachment's filename alone for classification.

The `intake_jobs` table stores provenance, source ID, hash, original path, category, confidence, result IDs, status and errors. `integration_logs`, `integration_health`, `integration_state` and `intake_notifications` are added idempotently. Original evidence and existing records are not deleted or recreated by migrations.

## Render deployment

**Before deploying**, compare this source with the actual GitHub repository; it has not been merged or deployed by this package. Back up the existing SQLite file and original evidence directory. Configure a persistent disk, for example `/var/data/careloop`, then set `CARELOOP_DATA_DIR=/var/data/careloop`. Without durable disk storage, evidence will not survive Render filesystem replacement.

Install command:

```sh
pip install -r requirements.txt
```

Web service start:

```sh
streamlit run app.py --server.address 0.0.0.0 --server.port $PORT --server.headless true
```

Worker start (separate always-on Render background worker with the same persistent storage, or an equivalent dedicated VM process):

```sh
python automation_worker.py
```

**Architectural constraint:** Render services do not automatically share each other's local disks; hosting Streamlit and a separate worker on two isolated instances with different filesystems will create two diverging SQLite databases. Do not enable independent workers until shared durable storage and a shared database are available, or run a single worker process on the same host with carefully managed lifecycle. For a production multi-instance solution, migrate the evidence DB to Postgres and originals to a private object store, plus role-based access and data retention policies. This release remains single-instance SQLite POC software.

Set `CARELOOP_ACCESS_PASSWORD` in Render. It is a basic POC gate, **not** role-based authorization or SSO; never expose real patient information or sensitive hospital records on a publicly accessible deployment without proper controls.

## Tests and troubleshooting

```sh
python -m pytest tests -v
python -m compileall -q app.py services database config
```

A false 'Connected' is not used: status only updates after a successful IMAP mailbox selection / Telegram API call. Failed network requests are recorded as `Connection failed`; credentials are not included in error logs. Source file size limit is 12 MiB. PDFs need valid signatures and readable labelled fields; image OCR needs Tesseract. Do not use the sample-data generator to create production records.
