# CARE LOOP compatibility upgrade manifest

**Source baseline:** Local earlier delivered `Hospital_Evidence_Automation_Command_Centre_POC.zip`. The referenced GitHub repository returned 404 through available connected accounts and could not be cloned in the sandbox due to network DNS restrictions. Therefore this is a **merge-ready offline upgrade** and NOT a committed change to the deployed GitHub project.

## Files updated
- `app.py`: CARE LOOP identity, Option-1 compact layout, icon rail, grouped evidence catalogue, priority Patient Fall and Daily Cleaning modules, tabbed workspace, inline record editing, review queue, email/Telegram screens, notifications popover, optional hosted access gate.
- `database/db.py`: persistent external data directory configured through `CARELOOP_DATA_DIR`.
- `services/integrations.py` (new): IMAP SSL read-only attachment ingestion, Telegram Bot API polling, keyword routing, de-duplication and staging, manual reclassification, cleaning event import.
- `automation_worker.py` (new): optional dedicated polling process.
- `scripts/remove_demo_records.py` (new): safe dry run and backup-before-demo-deletion.
- `tests/test_integrations.py` (new): routing and ingestion tests.
- `README.md`, `.env.example`, `START_WINDOWS.bat`, `.gitignore`: deployment and operational instructions.

## Original modules preserved
- `config/categories.py` all 16 IDs, original names and classifications.
- `services/document_parser.py`, `services/validation.py`, `services/workflows.py`, `services/report_service.py` existing extraction, validation and report behavior.
- `sample_data` used only as developer test fixtures; no UI controls expose sample downloads or sample processing.

## Workbook data used
The six tabs (Automation Catalogue, Quick Wins, Demo Roadmap, Overview, Collection Method Guide, Evidence Acceptance Notes) distinguish collection method, validation and evidence caveats. No blanket requirement for inbound mail is inferred. Email and folder collection is listed for EV-001/002/008/009; for maintenance records EV-013/016/018/019/020/022/023; and watch/mailbox approaches are listed for EV-027/028/029. EV-025 primarily specifies cleaning logs/checklists and EV-038 references HIS/EMR/incident management/quality reports. Telegram is a user-requested integration choice for EV-029, not an official mandatory collection method.

## External blockers
- Public production repository could not be inspected; confirm entry point and merge conflicts when access is granted.
- IMAP auth requires confirming `bharat@ignitexsol.com` provider and permitted credentials/OAuth method.
- Telegram requires bot token, authorized chat ID, permission and end-to-end testing.
- Existing camera cleaning project repository/API not provided; only structured JSON import can be tested.
- Render must have a persistent disk, configured secrets and single-writer SQLite design for this POC.
