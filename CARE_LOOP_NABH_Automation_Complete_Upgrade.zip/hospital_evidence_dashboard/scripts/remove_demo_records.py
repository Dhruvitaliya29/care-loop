"""Inspect and optionally remove ONLY explicitly demo-sourced documents/records.

Default is dry-run.  --apply creates a timestamped SQLite backup first.
Never delete uploaded evidence, masters, rules, or files from disk automatically.
"""
import sys,sqlite3,shutil,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from database.db import DB

def main(apply=False):
 if not DB.exists():
  print('Database does not exist; nothing to reset.');return
 with sqlite3.connect(DB) as db:
  tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  if not {'records','documents'}.issubset(tables):
   print('Schema not recognized; no changes made');return
  docids=[r[0] for r in db.execute("SELECT id FROM documents WHERE source_type='demo'")]
  count=db.execute("SELECT COUNT(*) FROM records WHERE document_id IN (SELECT id FROM documents WHERE source_type='demo')").fetchone()[0]
  print(f'Demo-source documents: {len(docids)}; linked records: {count}.')
  print('Uploaded and manually-created records will NOT be touched.')
  if not apply:
   print('DRY RUN ONLY. Use --apply after inspecting the report.');return
  backup=DB.with_name(DB.stem+'_backup_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.sqlite3')
  with sqlite3.connect(backup) as dest:db.backup(dest)
  print('Backup:',backup)
  db.execute('BEGIN')
  db.execute("DELETE FROM review_history WHERE record_id IN (SELECT id FROM records WHERE document_id IN (SELECT id FROM documents WHERE source_type='demo'))")
  db.execute("DELETE FROM notifications WHERE record_id IN (SELECT id FROM records WHERE document_id IN (SELECT id FROM documents WHERE source_type='demo'))")
  db.execute("DELETE FROM capa_links WHERE source_record_id IN (SELECT id FROM records WHERE document_id IN (SELECT id FROM documents WHERE source_type='demo'))")
  db.execute("DELETE FROM records WHERE document_id IN (SELECT id FROM documents WHERE source_type='demo')")
  db.execute("DELETE FROM documents WHERE source_type='demo'")
  db.commit()
  print('Demo records removed; source file bytes left on disk for deliberate review.')
if __name__=='__main__':main('--apply' in sys.argv)
