# CARE LOOP | NABH Automation

**Complete updated source package based on the user-provided CARE LOOP upgrade ZIP.** This is a local/Render-oriented hospital evidence POC; it has not been automatically deployed to GitHub or Render.

## Capabilities

- Compact Option-1-inspired single-page Streamlit workspace and CARE LOOP identity.
- Top-priority **Patient Fall Incident** and **Daily Cleaning** operational screens. Fall detection and floor-cleaning camera inference are **not** included or simulated; existing manual and structured event import features remain.
- Existing 16 catalogue categories and their actual parsing, validation, exception detection, source preservation, editable fields, reviewer sign-off, reports, CSV/XLSX exports and SQLite persistence.
- **Shared intake pipeline** (`services/intake.py`) used for direct uploads, incoming email attachments, and Telegram documents. Stores originals, checks formats and size, runs classification, invokes the original category-specific parser and validator, handles duplicates and routing, logs processing and raises review/notification events.
- **IMAP connector** (`services/connectors.py`) with TLS, read-only mailbox selection, UID-based checkpoints, sender allowlist, error handling and automatic evidence routing. Provider must support the configured authentication method.
- **Official Telegram Bot API connector** for EV-029 laundry receipts: authorized chat allowlist, photos/files, persistent offsets, actual status replies, error handling and logs.
- **Automation Centre** showing actual connection health, last successful sync, ingestion totals and processing logs. Upper-right unread-notification popover and a review queue for unclassified or failed documents.
- **Independent worker** (`automation_worker.py`) avoids starting pollers per Streamlit rerun, uses a nonblocking OS lock on Unix and supports graceful shutdown.
- Additive, idempotent SQLite migrations. Does not delete or replace an existing SQLite database or seeded master tables.

## Run locally (Windows)

Install Python 3.11+; open a PowerShell window inside `hospital_evidence_dashboard`:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py
```

The app starts at `http://localhost:8501` if the Streamlit process launches successfully. A separate polling process is necessary for unattended email and Telegram intake:

```powershell
.\.venv\Scripts\python.exe automation_worker.py
```

Configure secrets through Windows environment variables or your deployment secret manager; see `.env.example` and `docs/INTEGRATION_SETUP.md`. The `.env.example` file is documentation only and **does not load automatically**.

## Test

```powershell
.\.venv\Scripts\python.exe -m pytest tests -v
.\.venv\Scripts\python.exe -m compileall -q app.py automation_worker.py services database config
```

Build environment: **18 Python unit/integration tests passed**. Tests include mocked IMAP and Telegram APIs, real sample-document extraction, invalid/empty file rejection, cross-channel SHA dedupe, sender/chat authorization, worker state, review, SQLite and exports. A browser smoke test was not possible because Streamlit was not installed in this build environment. Email/Telegram connections were not tested against live external accounts; actual access is required.

## Render deployment

Before merging, compare this package with the actual GitHub repository and back up existing data. Use a persistent mount and set `CARELOOP_DATA_DIR` to its absolute mount location. Start the UI using:

```sh
streamlit run app.py --server.address 0.0.0.0 --server.port $PORT --server.headless true
```

Start the worker with `python automation_worker.py`, but **do not run the UI and worker on separate isolated Render disks using the same SQLite path**: they cannot see the same database/files. Use a shared database and private object store for separate Render services, or co-locate both on one persistent host with lifecycle management. Ensure `CARELOOP_ACCESS_PASSWORD` is configured in hosted environments. This simple password gate is not production RBAC.

For complete IMAP provider discovery, Telegram bot creation, security notes and Render restrictions, read `docs/INTEGRATION_SETUP.md`. For the architecture baseline, read `docs/UPGRADE_AUDIT.md`.

## Operational safeguards

- Fictional records are not real patient records or formal compliance determinations.
- Uncertain classifications and failed extractions remain available for human review with original files preserved.
- No passwords/bot tokens are embedded in source code or logs.
- Uploaded files are not automatically approved because their fields pass basic validation.
- Never expose real clinical/patient material publicly until authentication, RBAC, storage encryption, review rights, consent, retention and other appropriate safeguards are professionally verified.
- An actual mailbox provider and credentials, Telegram bot/chat details, and external camera project interfaces are not included. Live integrations must not display Connected until protocol connectivity succeeds.
