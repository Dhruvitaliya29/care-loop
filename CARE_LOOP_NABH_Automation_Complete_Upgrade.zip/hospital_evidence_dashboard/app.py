"""CARE LOOP | NABH Automation: compact Streamlit operations console.

The app is a local-first upgrade of the earlier project package. No live connection
is claimed without verified credentials, and automated checks never imply approval.
"""
import os, sys, json, datetime, sqlite3, hmac, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import pandas as pd
import streamlit as st
from config.categories import CAT,SCHEMAS
from database.db import connect,records,review,summary,notifications,save_record
from sample_data.seed import initialise
from services.validation import validate
from services.workflows import process_bytes,record_key
from services.intake import migrate,intake_document,process_job
from services.report_service import csv_bytes,excel_bytes
from services.integrations import (init_integrations,sync_imap,sync_telegram,ingest_cleaning_json,
                                   ingest_cleaning_event,ROUTES,route_pending)

st.set_page_config(page_title='CARE LOOP | NABH Automation',page_icon='✚',layout='wide',initial_sidebar_state='collapsed')
# Optional local access gate; require a configured password for hosted Render use.
access_secret=os.getenv('CARELOOP_ACCESS_PASSWORD','')
if os.getenv('RENDER') and not access_secret:
 st.error('Hosted deployment is locked: configure CARELOOP_ACCESS_PASSWORD in Render secrets.')
 st.stop()
if access_secret and not st.session_state.get('care_access_ok',False):
 st.title('CARE LOOP · Secure access')
 entered=st.text_input('Access password',type='password')
 if st.button('Sign in'):
  if hmac.compare_digest(entered,access_secret):
   st.session_state.care_access_ok=True;st.rerun()
  else:st.error('Invalid password')
 st.stop()
initialise();init_integrations();migrate()
if 'section' not in st.session_state:st.session_state.section='Overview'
if 'module' not in st.session_state:st.session_state.module='EV-001'

st.markdown('''<style>
:root{--ink:#13273b;--accent:#0b7883}
.stApp{background:#f7f9fb;color:var(--ink)}
[data-testid="stHeader"]{background:transparent;height:2rem}
.block-container{padding:0.55rem 1.4rem 1.6rem;max-width:1900px}
h1,h2,h3{color:#142c42!important;letter-spacing:-.025em}
h1{font-size:1.43rem!important;margin-bottom:.15rem!important}
h2{font-size:1.14rem!important;margin-bottom:.2rem!important}
h3{font-size:1.04rem!important;margin-bottom:.2rem!important}
p{margin-bottom:.35rem}
[data-testid="stMetric"]{border:1px solid #e3e9ef;border-radius:8px;background:#fff;padding:.45rem .75rem;min-height:65px}
[data-testid="stMetricLabel"]{font-size:.73rem;color:#617387}
[data-testid="stMetricValue"]{font-size:1.34rem;color:#17354e}
[data-testid="stVerticalBlockBorderWrapper"]{background:#fff;border-color:#e4eaf0;border-radius:8px;padding:.1rem}
.stButton>button{border-radius:6px;min-height:2rem;padding:.2rem .6rem;font-size:.81rem}
.stButton>button[kind="primary"]{background:#0a6f80;border-color:#0a6f80;color:white}
[data-testid="stFileUploader"]{padding:0;border-radius:6px}
[data-testid="stFileUploaderDropzone"]{padding:.42rem!important;min-height:62px!important}
[data-testid="stFileUploaderDropzoneInstructions"]{font-size:.77rem}
[data-testid="stDataFrame"], [data-testid="stTable"]{border-radius:6px}
[data-testid="stTabs"] [data-baseweb="tab"]{height:35px;font-size:.81rem;padding:0 .8rem}
[data-testid="stPopover"] button{min-height:1.9rem}
hr{margin:.65rem 0}
.smallmuted{font-size:.77rem;color:#6b7a8d}
.care-title{font-weight:800;letter-spacing:.045em;color:#12354a;font-size:1.17rem}
.care-subtitle{font-weight:500;font-size:.72rem;color:#658093;letter-spacing:.04em}
.sectionlabel{color:#758698;font-size:.71rem;font-weight:750;text-transform:uppercase;letter-spacing:.07em;margin:.45rem 0 .17rem}
</style>''',unsafe_allow_html=True)

# Compact top bar; notification popover instead of a permanent right-hand column.
h1,h2,h3=st.columns([.67,.23,.10],vertical_alignment='center')
with h1:st.markdown('<span class="care-title">✚ &nbsp;CARE LOOP</span> <span class="care-subtitle">&nbsp; | &nbsp; NABH Automation</span>',unsafe_allow_html=True)
with h2:st.caption('Evidence & operations management')
with h3:
 with st.popover('♧ Alerts',use_container_width=True):
  with connect() as db:
   latest=[dict(r) for r in db.execute('SELECT * FROM intake_notifications WHERE is_read=0 ORDER BY id DESC LIMIT 15')]
  st.markdown('##### Notifications')
  if not latest:st.caption('No unread alerts')
  for alert in latest:
   col_a,col_b=st.columns([.83,.17])
   col_a.caption(alert['message'])
   if col_b.button('✓',key='read_'+str(alert['id']),help='Mark as read'):
    with connect() as db:db.execute('UPDATE intake_notifications SET is_read=1 WHERE id=?',(alert['id'],))
    st.rerun()

# Compact navigation is persistent; source screen is chosen by state.
rail,left,right=st.columns([.075,.215,.710],gap='small')
with rail:
 for icon,label,target in [('⌂','Home','Overview'),('▤','Evidence','Staff and Training'),('✓','Reviews','Pending Reviews & Evidences'),('⚙','Automation','Automation Centre'),('▧','Laundry','Laundry Messaging'),('⚙','Settings','Integration Settings')]:
  if st.button(icon,key='rail_'+target,help=label,use_container_width=True):
   st.session_state.section=target;st.rerun()
with left:
 st.text_input('Search sections or evidence',key='navigation_search',placeholder='Search…',label_visibility='collapsed')
 q=st.session_state.navigation_search.lower().strip()
 def nav(label,target,priority=False):
  if q and q not in label.lower() and q not in target.lower():return
  if st.button(('▸ ' if st.session_state.section==target else '')+label,key='nav_'+target,
               use_container_width=True,type='primary' if st.session_state.section==target else 'secondary'):
   st.session_state.section=target
   st.rerun()
 st.markdown('<div class="sectionlabel">Priority Operations</div>',unsafe_allow_html=True)
 nav('Patient Fall Incident','Patient Fall Incident',True)
 nav('Daily Cleaning','Daily Cleaning',True)
 st.markdown('<div class="sectionlabel">Evidence Management</div>',unsafe_allow_html=True)
 nav('Overview','Overview')
 groups=list(dict.fromkeys(c['group'] for c in CAT.values()))
 for group in groups:
  if group in ('Patient Safety','Housekeeping and Cleaning'):continue
  nav(group,group)
 st.markdown('<div class="sectionlabel">Management</div>',unsafe_allow_html=True)
 nav('Pending Reviews & Evidences','Pending Reviews & Evidences')
 nav('Automation Centre','Automation Centre')
 nav('Integration Settings','Integration Settings')


def metric_row(items):
 for col,(name,value) in zip(st.columns(len(items),gap='small'),items):
  with col:st.metric(name,value)

def table_view(rows,fields=None,height=300):
 if not rows:return st.info('No records received yet.')
 frame=pd.DataFrame(rows)
 if fields:frame=frame[[f for f in fields if f in frame.columns]]
 st.dataframe(frame,use_container_width=True,hide_index=True,height=height)

def edit_record(cat,r):
 data=r['data'].copy()
 with st.expander('Edit extracted fields',expanded=False):
  edited=st.data_editor(pd.DataFrame([data]),num_rows='fixed',use_container_width=True,hide_index=True,key=f'edit_{cat}_{r["id"]}')
  if st.button('Save changes',key=f'save_{cat}_{r["id"]}'):
   clean={k:'' if pd.isna(v) else str(v).strip() for k,v in edited.iloc[0].items()}
   status,issues=validate(cat,clean)
   # Keep original record key and source pointer; preserve original document.
   save_record(cat,r['record_key'],clean,status,issues,r['document_id'])
   st.success('Changes saved. Human review reset to pending.');st.rerun()

def review_one(cat,record):
 st.caption('Status: '+record['validation_status']+' · Review: '+record['review_status'])
 if record['issues']:
  st.error('; '.join(record['issues']))
 with st.form('review_form_'+cat+'_'+str(record['id'])):
  reviewer=st.text_input('Reviewer / staff ID',key='rv_'+str(record['id']))
  decision=st.selectbox('Decision',['Needs Correction','Approved','Rejected'],key='decision_'+str(record['id']))
  comment=st.text_input('Review notes',key='comment_'+str(record['id']))
  if st.form_submit_button('Save review'):
   if not reviewer.strip():st.error('Reviewer identity required')
   else:review(record['id'],decision,reviewer.strip(),comment);st.success('Decision recorded');st.rerun()
 with connect() as db:
  history=[dict(x) for x in db.execute('SELECT decision,reviewer,comment,reviewed_at FROM review_history WHERE record_id=? ORDER BY id DESC',(record['id'],))]
  doc=db.execute('SELECT filename,stored_path FROM documents WHERE id=?',(record['document_id'],)).fetchone() if record['document_id'] else None
 if doc and Path(doc['stored_path']).is_file():
  st.download_button('Download original evidence',Path(doc['stored_path']).read_bytes(),file_name=doc['filename'],key='orig_'+str(record['id']))
 if history:
  with st.expander('Audit history'):table_view(history,height=180)

def evidence_module(cat):
 c=CAT[cat]
 st.title(c['name'])
 st.caption(c['group'])
 tabs=st.tabs(['Workspace','Documents & Register','Validation','Review & History'])
 with tabs[0]:
  a,b=st.columns([.63,.37],gap='small')
  with a:
   upload=st.file_uploader('Upload evidence document',type=['pdf','csv','xlsx','docx','jpg','jpeg','png'],key='up_'+cat)
  with b:
   st.write('')
   if st.button('Load & Process',type='primary',use_container_width=True,key='run_'+cat):
    if not upload:st.warning('Choose a document first')
    else:
     try:
      result=intake_document('manual',f'{cat}:{hashlib.sha256(upload.getvalue()).hexdigest()}',upload.name,upload.getvalue(),category_hint=cat)
      st.success(f"Intake status: {result['status']} · category {cat}")
     except Exception as exc:st.error(f'Processing failed: {exc}')
  rr=records(cat)
  if rr:
   metric_row([('Records',len(rr)),('Pending review',sum(r['review_status']=='Pending Review' for r in rr)),('Exceptions',sum(bool(r['issues']) for r in rr))])
   st.markdown('##### Extracted fields')
   table_view([{'record_id':r['id'],**r['data'],'status':r['validation_status']} for r in rr],height=245)
   with st.expander('Edit record inline'):
    ix=st.selectbox('Record',range(len(rr)),format_func=lambda x:f'#{rr[x]["id"]} · {rr[x]["record_key"][:42]}',key='editpick_'+cat)
    edit_record(cat,rr[ix])
  else:st.caption('Upload a document to create the first evidence record.')
 with tabs[1]:
  rows=records(cat)
  table_view([{'record_id':r['id'],'document':r['source_filename'],'received':r['created_at'],'validation':r['validation_status'],'review':r['review_status']} for r in rows])
  if rows:
   st.download_button('Export CSV',csv_bytes(cat),file_name=f'{cat}_register.csv',mime='text/csv')
   st.download_button('Export Excel',excel_bytes(cat),file_name=f'{cat}_register.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
 with tabs[2]:
  rows=records(cat)
  table_view([{'id':r['id'],'result':r['validation_status'],'missing / exceptions':'; '.join(r['issues']),'document':r['source_filename']} for r in rows])
 with tabs[3]:
  rows=records(cat)
  if rows:
   pick=st.selectbox('Choose evidence',range(len(rows)),format_func=lambda i:f'#{rows[i]["id"]} · {rows[i]["record_key"][:60]}',key='reviewselect_'+cat)
   review_one(cat,rows[pick])
  else:st.caption('No review items yet.')


def falls():
 st.title('Patient Fall Incident')
 with connect() as db:
  rows=[dict(r) for r in db.execute('SELECT * FROM fall_incidents ORDER BY id DESC')]
 metric_row([('Total incidents',len(rows)),('Open investigations',sum(r['status'] in ('Open','Investigating') for r in rows)),('Pending actions',sum(r['status']=='Follow-up' for r in rows)),('Closed',sum(r['status']=='Closed' for r in rows))])
 report,register,reviewtab=st.tabs(['Report incident','Incident register','Investigation & closure'])
 with report:
  with st.form('new_fall'):
   aa,bb,cc=st.columns(3)
   incident_date=aa.date_input('Incident date')
   incident_time=aa.time_input('Incident time')
   at=datetime.datetime.combine(incident_date,incident_time)
   ward=bb.text_input('Ward / location')
   severity=cc.selectbox('Severity',['No injury','Minor','Moderate','Severe','Unknown'])
   anonymous=st.text_input('Anonymized reference (optional)',help='Do not enter MRN, name, phone, or real patient identifier')
   desc=st.text_area('Incident description')
   ac,bc=st.columns(2)
   injury=ac.text_input('Injury observed')
   immediate=bc.text_input('Immediate action taken')
   witness=st.text_input('Witness / staff role or ID')
   if st.form_submit_button('Save incident',type='primary'):
    if not ward.strip() or not desc.strip():st.error('Location and incident description required')
    else:
     ref='FALL-'+datetime.datetime.now().strftime('%Y%m%d%H%M%S%f')
     with connect() as db:
      db.execute('INSERT INTO fall_incidents(incident_id,incident_at,location,anonymous_patient_ref,description,severity,injury,immediate_action,witness_staff) VALUES(?,?,?,?,?,?,?,?,?)',(ref,at.isoformat(),ward.strip(),anonymous.strip(),desc.strip(),severity,injury,immediate,witness))
     st.success('Incident registered for investigation');st.rerun()
 with register:
  table_view([{k:v for k,v in r.items() if k not in ('anonymous_patient_ref','description','raw_json')} for r in rows],height=330)
 with reviewtab:
  if rows:
   pick=st.selectbox('Incident',range(len(rows)),format_func=lambda i:rows[i]['incident_id'])
   row=rows[pick]
   with st.form('fall_investigation'):
    factors=st.text_area('Contributing factors',value=row['contributing_factors'] or '')
    investigation=st.text_area('Investigation findings',value=row['investigation'] or '')
    capa=st.text_input('Corrective / preventive action',value=row['capa'] or '')
    follow=st.text_input('Follow-up',value=row['follow_up'] or '')
    status=st.selectbox('Status',['Open','Investigating','Follow-up','Closed'],index=['Open','Investigating','Follow-up','Closed'].index(row['status']))
    reviewer=st.text_input('Reviewer ID',value=row['reviewer'] or '')
    if st.form_submit_button('Save investigation'):
     if not reviewer.strip():st.error('Reviewer ID required')
     else:
      with connect() as db:
       db.execute('UPDATE fall_incidents SET contributing_factors=?,investigation=?,capa=?,follow_up=?,status=?,reviewer=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(factors,investigation,capa,follow,status,reviewer,row['id']))
      st.success('Investigation updated');st.rerun()
  else:st.caption('No incidents recorded.')


def cleaning():
 st.title('Daily Cleaning')
 with connect() as db:
  rows=[dict(r) for r in db.execute('SELECT * FROM cleaning_events ORDER BY event_time DESC')]
 metric_row([('Events',len(rows)),('Awaiting review',sum(r['review_status']=='Pending Review' for r in rows)),('Verified by supervisor',sum(bool(r['verified_by']) for r in rows))])
 events,receive=st.tabs(['Cleaning events','Import external events'])
 with events:
  a,b,c=st.columns(3)
  loc=a.selectbox('Location',['All']+sorted({r['location'] for r in rows if r['location']}))
  status=b.selectbox('Status',['All']+sorted({r['detected_status'] for r in rows if r['detected_status']}))
  date=c.date_input('From date',value=None)
  filt=[r for r in rows if (loc=='All' or r['location']==loc) and (status=='All' or r['detected_status']==status) and (not date or str(r['event_time'])[:10]>=date.isoformat())]
  table_view([{k:v for k,v in r.items() if k not in ('raw_json',)} for r in filt],height=320)
  if rows:
   chosen=st.selectbox('Event to review',range(len(rows)),format_func=lambda i:rows[i]['event_id'])
   r=rows[chosen]
   st.caption('Camera detection is an activity event; supervisor verification remains separate.')
   verifier=st.text_input('Supervisor ID',key='cleaning_verifier')
   if st.button('Record supervisor verification'):
    if not verifier.strip():st.error('Supervisor ID required')
    else:
     with connect() as db:db.execute("UPDATE cleaning_events SET verified_by=?,review_status='Reviewed' WHERE id=?",(verifier,r['id']))
     st.success('Review recorded');st.rerun()
 with receive:
  st.caption('Imports structured events exported by your existing floor-cleaning system. No camera processing runs here.')
  file=st.file_uploader('Cleaning event JSON',type=['json'],key='cleaning_events')
  if st.button('Import events',type='primary'):
   if not file:st.warning('Select a JSON event export')
   else:
    try:st.success(str(ingest_cleaning_json(file.read())))
    except Exception as exc:st.error(str(exc))
  with st.expander('Expected event contract'):
   st.code('{"event_id":"clean-001","timestamp":"2026-11-19T11:30:00+05:30","location":"ICU","camera_id":"CAM-04","status":"activity_detected","confidence":0.87,"screenshot":"secure-file-reference","alert":"","verified_by":""}',language='json')
  st.caption('An API/webhook connection can be added once the actual cleaning repository or endpoint is inspected.')


def pending():
 st.title('Pending Reviews & Evidences')
 with connect() as db:
  queue=[dict(x) for x in db.execute("SELECT id,source,filename,category_id,confidence,error,status,created_at FROM intake_jobs WHERE status IN ('Pending Review','Failed') ORDER BY id DESC LIMIT 150")]
 if queue:
  st.markdown('##### Incoming documents for review')
  table_view(queue,fields=['id','source','filename','category_id','confidence','status','error','created_at'],height=220)
  chosen=st.selectbox('Select incoming attachment',[r['id'] for r in queue],format_func=lambda x: f'#{x} · '+next(r['filename'] for r in queue if r['id']==x))
  cat=st.selectbox('Assign category',list(CAT),format_func=lambda x:CAT[x]['name'],key='inbound_cat')
  c1,c2,c3=st.columns(3)
  if c1.button('Route and process',type='primary'):
   st.info(str(process_job(chosen,category_hint=cat)));st.rerun()
  if c2.button('Retry automatic classification'):
   st.info(str(process_job(chosen)));st.rerun()
  with connect() as db:job=db.execute('SELECT filename,stored_path FROM intake_jobs WHERE id=?',(chosen,)).fetchone()
  if job and Path(job['stored_path']).exists():
   c3.download_button('Download original',Path(job['stored_path']).read_bytes(),file_name=job['filename'])
 allrows=[r for r in records() if r['review_status'] not in ('Approved','Rejected')]
 table_view([{'ID':r['id'],'Module':r['category_id'],'Document':r['source_filename'],'Received':r['created_at'],'Status':r['review_status'],'Missing / exception':'; '.join(r['issues'])[:150],'Reviewer':r['reviewer']} for r in allrows],height=320)
 if allrows:
  ix=st.selectbox('Open evidence',range(len(allrows)),format_func=lambda i:f"#{allrows[i]['id']} · {allrows[i]['category_id']} · {allrows[i]['record_key'][:28]}")
  review_one(allrows[ix]['category_id'],allrows[ix])


def automation_centre():
 st.title('Automation Centre')
 with connect() as db:
  rows=[dict(x) for x in db.execute('SELECT * FROM integration_health')]
  logs=[dict(x) for x in db.execute('SELECT created_at,integration,filename,category_id,stage,status,detail FROM integration_logs ORDER BY id DESC LIMIT 100')]
  counts=[dict(x) for x in db.execute('SELECT source,status,COUNT(*) count FROM intake_jobs GROUP BY source,status')]
 state={r['name']:r for r in rows}
 a,b=st.columns(2,gap='small')
 with a:
  st.markdown('#### Email evidence intake')
  info=state.get('email',{})
  st.caption('Mailbox: '+(os.getenv('EMAIL_USERNAME') or os.getenv('CARELOOP_IMAP_USER') or 'Not configured'))
  st.write('Connection: **'+info.get('status','Not configured')+'**')
  st.caption('Last successful sync: '+str(info.get('last_success') or 'Not yet verified'))
  if st.button('Sync email',key='sync_email'):
   from services.connectors import sync_email
   st.info(sync_email());st.rerun()
 with b:
  st.markdown('#### Telegram laundry intake')
  info=state.get('telegram',{})
  st.write('Connection: **'+info.get('status','Not configured')+'**')
  st.caption('Last successful sync: '+str(info.get('last_success') or 'Not yet verified'))
  if st.button('Sync Telegram',key='sync_tg'):
   from services.connectors import sync_laundry
   st.info(sync_laundry());st.rerun()
 st.markdown('##### Intake totals')
 table_view(counts,height=130)
 st.markdown('##### Recent integration activity')
 table_view(logs,height=310)
 with st.expander('Configuration and deployment settings'):
  st.caption('Connections and polling enable switches are set using deployment environment variables. Secrets are never displayed here.')
  st.code('EMAIL_ENABLED=true\nEMAIL_HOST=imap.example.org\nEMAIL_USERNAME=authorized@example.org\nEMAIL_FOLDER=INBOX\nTELEGRAM_ENABLED=true\nTELEGRAM_ALLOWED_CHAT_IDS=-100123456789\nCARELOOP_DATA_DIR=/var/data/careloop')


def settings_page():
 st.title('Integration Settings')
 statuses=[('Email IMAP','CARELOOP_IMAP_HOST','CARELOOP_IMAP_USER','CARELOOP_IMAP_PASSWORD'),('Telegram','CARELOOP_TELEGRAM_BOT_TOKEN','CARELOOP_TELEGRAM_CHAT_ID'),('Persistent storage','CARELOOP_DATA_DIR')]
 table_view([{'Integration':x[0],'Configuration': 'Configured, unverified' if all(os.getenv(k) for k in x[1:]) else 'Missing settings','Keys':', '.join(x[1:])} for x in statuses],height=200)
 st.caption('Connection status changes only after a successful manual synchronization. Configure environment variables in Render or Windows; never commit secrets.')

with right:
 section=st.session_state.section
 if section=='Overview':
  st.title('Overview')
  counts=summary()
  metric_row([('Evidence Categories',16),('Working Modules',16),('Evidence Records',counts['total']),('Pending Reviews',counts['pending']),('Overdue / Expired',counts['overdue']),('Exceptions',counts['exceptions'])])
  st.markdown('##### Evidence management')
  table_view([{'Category':c['name'],'Section':c['group'],'Records':len(records(c['id']))} for c in CAT.values()],height=470)
 elif section=='Patient Fall Incident':falls()
 elif section=='Daily Cleaning':cleaning()
 elif section=='Pending Reviews & Evidences':pending()
 elif section=='Automation Centre':automation_centre()
 elif section=='Integration Settings':settings_page()
 else:
  choices=[c for c in CAT.values() if c['group']==section]
  if choices:
   st.markdown('##### '+section)
   ids=[c['id'] for c in choices]
   current=st.session_state.module if st.session_state.module in ids else ids[0]
   picked=st.selectbox('Evidence module',ids,index=ids.index(current),format_func=lambda i:CAT[i]['name'],label_visibility='collapsed',key='choose_'+section)
   st.session_state.module=picked
   evidence_module(picked)
