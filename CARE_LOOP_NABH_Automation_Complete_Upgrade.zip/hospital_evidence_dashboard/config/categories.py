"""Exact category IDs/names and classifications from the supplied catalogue."""
CATEGORIES = [
('EV-001','Staff training attendance and certificates','Staff and Training','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','Training attendance and certificates'),
('EV-002','Staff professional licenses and qualification records','Staff and Training','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','Professional registration and credentials'),
('EV-008','CAPA documentation and closure evidence','Quality and Corrective Actions','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','Corrective and preventive actions'),
('EV-009','Vendor agreements and maintenance contracts','Vendor and Maintenance','Maybe','P2 - Next','Low','2 - Domain Workflows','Vendor contracts and AMC expiries'),
('EV-013','Fire extinguisher service and inspection records','Fire and Safety','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','Extinguisher inspection history'),
('EV-016','Fire alarm testing records','Fire and Safety','No','P2 - Next','Medium','2 - Domain Workflows','Fire alarm testing and faults'),
('EV-018','Generator maintenance and test records','Engineering and Infrastructure','No','P2 - Next','Medium','2 - Domain Workflows','DG maintenance and testing'),
('EV-019','Medical gas system maintenance records','Engineering and Infrastructure','No','P2 - Next','Medium','2 - Domain Workflows','Medical gas maintenance'),
('EV-020','Lift inspection and maintenance certificates','Engineering and Infrastructure','No','P2 - Next','Medium','2 - Domain Workflows','Lift certificates and service'),
('EV-022','Pest-control service records','Engineering and Infrastructure','No','P2 - Next','Medium','2 - Domain Workflows','Pest-control visit documentation'),
('EV-023','Preventive maintenance schedules','Engineering and Infrastructure','No','P2 - Next','Medium','2 - Domain Workflows','Preventive maintenance of assets'),
('EV-025','Daily cleaning and disinfection logs','Housekeeping and Cleaning','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','Daily cleaning and supervisor review'),
('EV-027','Biomedical waste segregation inspection records','Biomedical Waste','No','P2 - Next','Medium','2 - Domain Workflows','Colour-coded waste segregation inspection'),
('EV-028','Biomedical waste vendor collection manifests','Biomedical Waste','Yes','P1 - Quick Win','Low','1 - Evidence Foundation','CBWTF collection and weight reconciliation'),
('EV-029','Laundry and linen processing records','Laundry and Linen','No','P2 - Next','Medium','2 - Domain Workflows','Linen batch reconciliation'),
('EV-038','Patient fall incident reports','Patient Safety','No','P2 - Next','Medium','2 - Domain Workflows','Fictional patient incident and investigation'),
]
CAT = {r[0]: {'id':r[0], 'name':r[1], 'group':r[2], 'candidate':r[3], 'priority':r[4], 'complexity':r[5], 'phase':r[6], 'description':r[7]} for r in CATEGORIES}
# Each module has its own relevant schema; required and date fields are not necessarily statutory requirements.
SCHEMAS = {
'EV-001':('employee_id','employee_name','training_topic','training_date','trainer','certificate_number','competency_status'),
'EV-002':('employee_id','employee_name','qualification','council','registration_number','issue_date','expiry_date'),
'EV-008':('capa_id','source_evidence_id','finding','root_cause','action_owner','due_date','corrective_action','effectiveness_status'),
'EV-009':('contract_number','vendor_id','vendor_name','asset_id','start_date','end_date','scope'),
'EV-013':('asset_id','inspection_date','service_date','next_due_date','vendor_id','pressure_status','seal_status'),
'EV-016':('asset_id','test_date','next_due_date','vendor_id','detector_test','call_point_test','observations'),
'EV-018':('asset_id','service_date','next_due_date','vendor_id','engine_hours','frequency_hz','result'),
'EV-019':('asset_id','inspection_date','next_due_date','vendor_id','pressure_bar','alarm_result','observations'),
'EV-020':('asset_id','certificate_number','inspection_date','valid_until','vendor_id','observations'),
'EV-022':('service_id','vendor_id','location','visit_date','next_visit','treatment','observation'),
'EV-023':('asset_id','department','last_service_date','frequency_days','next_due_date','assigned_owner','status'),
'EV-025':('location','date','time','employee_id','procedure','completion_status','supervisor_id'),
'EV-027':('inspection_id','department','inspection_date','inspector_id','yellow_check','red_check','white_check','blue_check'),
'EV-028':('manifest_number','vendor_id','collection_date','waste_category','weight_kg','barcode','vehicle_number','handover_by'),
'EV-029':('batch_id','department','collection_date','linen_type','sent_qty','returned_qty','process_status'),
'EV-038':('incident_id','incident_date','department','severity','immediate_action','investigation_owner','investigation_status','capa_id'),
}
DATE_FIELDS = {'training_date','issue_date','expiry_date','due_date','start_date','end_date','inspection_date','service_date','next_due_date','test_date','valid_until','visit_date','next_visit','last_service_date','date','collection_date','incident_date'}
REFERENCE = {'EV-001':'S01/S06','EV-002':'S01','EV-008':'S01','EV-009':'CONFIG','EV-013':'S07/S08 (building only)','EV-016':'S07/S08 (building only)','EV-018':'CONFIG','EV-019':'CONFIG','EV-020':'CONFIG (state review pending)','EV-022':'S06/CONFIG','EV-023':'S01/CONFIG','EV-025':'S06','EV-027':'S03/S05','EV-028':'S03/S05','EV-029':'S06','EV-038':'S01'}
LABEL = 'DEMO DATA – NOT AN ACTUAL HOSPITAL RECORD'
