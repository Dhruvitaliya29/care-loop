"""SQLite persistence; every record and document is traceable."""
import sqlite3, json, hashlib, datetime, os
from pathlib import Path
BASE = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.environ.get('CARELOOP_DATA_DIR', str(BASE))).expanduser().resolve()
DATA_DIR.mkdir(parents=True,exist_ok=True)
DB = DATA_DIR/'database'/'evidence.sqlite3'
DB.parent.mkdir(parents=True,exist_ok=True)
def connect():
    db=sqlite3.connect(DB,timeout=20)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db

def init_db():
    with connect() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS departments(id TEXT PRIMARY KEY,name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS staff(id TEXT PRIMARY KEY,name TEXT NOT NULL,department TEXT,designation TEXT);
        CREATE TABLE IF NOT EXISTS vendors(id TEXT PRIMARY KEY,name TEXT NOT NULL,service TEXT);
        CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY,name TEXT,department TEXT,vendor_id TEXT,location TEXT,frequency_days INTEGER);
        CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY AUTOINCREMENT, category_id TEXT,filename TEXT, stored_path TEXT,sha256 TEXT,source_type TEXT,uploaded_at TEXT, UNIQUE(category_id,sha256,source_type));
        CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY AUTOINCREMENT,category_id TEXT NOT NULL,record_key TEXT NOT NULL, document_id INTEGER, data_json TEXT NOT NULL, validation_status TEXT, exceptions_json TEXT,review_status TEXT DEFAULT 'Pending Review', reviewer TEXT,reviewed_at TEXT, created_at TEXT,updated_at TEXT, UNIQUE(category_id,record_key), FOREIGN KEY(document_id) REFERENCES documents(id));
        CREATE TABLE IF NOT EXISTS review_history(id INTEGER PRIMARY KEY AUTOINCREMENT,record_id INTEGER,decision TEXT,reviewer TEXT,comment TEXT,reviewed_at TEXT);
        CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,record_id INTEGER,category_id TEXT,message TEXT,created_at TEXT,is_read INTEGER DEFAULT 0, UNIQUE(record_id,message));
        CREATE TABLE IF NOT EXISTS rule_definitions(id TEXT PRIMARY KEY,category_id TEXT,classification TEXT,description TEXT,source_reference TEXT,threshold TEXT);
        CREATE TABLE IF NOT EXISTS capa_links(capa_id TEXT PRIMARY KEY,source_category TEXT,source_record_id INTEGER,action_owner TEXT,status TEXT);
        ''')

def insert_master(table,rows):
    with connect() as db:
        for row in rows:
            cols=','.join(row); marks=','.join('?' for _ in row)
            db.execute(f'INSERT OR IGNORE INTO {table} ({cols}) VALUES ({marks})',tuple(row.values()))

def create_document(category,filename,bytes_data,source_type='upload'):
    uploads=DATA_DIR/'uploads'; uploads.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(bytes_data).hexdigest()
    suffix=Path(filename).suffix.lower()
    stored=uploads/f'{category.lower()}_{digest[:20]}{suffix}'
    if not stored.exists(): stored.write_bytes(bytes_data)
    now=datetime.datetime.now().isoformat(timespec='seconds')
    with connect() as db:
        db.execute('INSERT OR IGNORE INTO documents(category_id,filename,stored_path,sha256,source_type,uploaded_at) VALUES(?,?,?,?,?,?)',(category,filename,str(stored),digest,source_type,now))
        return db.execute('SELECT id FROM documents WHERE category_id=? AND sha256=? AND source_type=?',(category,digest,source_type)).fetchone()['id']

def save_record(category,key,data,status,issues,doc_id=None):
    now=datetime.datetime.now().isoformat(timespec='seconds')
    with connect() as db:
        db.execute('''INSERT INTO records(category_id,record_key,document_id,data_json,validation_status,exceptions_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(category_id,record_key) DO UPDATE SET document_id=excluded.document_id,data_json=excluded.data_json,validation_status=excluded.validation_status,exceptions_json=excluded.exceptions_json,updated_at=excluded.updated_at,review_status='Pending Review',reviewer=NULL,reviewed_at=NULL''',(category,key,doc_id,json.dumps(data,ensure_ascii=False),status,json.dumps(issues),now,now))
        rid=db.execute('SELECT id FROM records WHERE category_id=? AND record_key=?',(category,key)).fetchone()['id']
        for issue in issues:
            db.execute('INSERT OR IGNORE INTO notifications(record_id,category_id,message,created_at) VALUES (?,?,?,?)',(rid,category,issue,now))
        return rid

def records(category=None):
    with connect() as db:
        data=db.execute('SELECT r.*,d.filename source_filename FROM records r LEFT JOIN documents d ON r.document_id=d.id '+('WHERE r.category_id=? ' if category else '')+'ORDER BY r.id DESC',(category,) if category else ()).fetchall()
    return [dict(x) | {'data':json.loads(x['data_json']), 'issues':json.loads(x['exceptions_json'] or '[]')} for x in data]

def review(record_id,decision,reviewer,comment=''):
    assert decision in ('Approved','Rejected','Needs Correction')
    now=datetime.datetime.now().isoformat(timespec='seconds')
    with connect() as db:
        db.execute('UPDATE records SET review_status=?,reviewer=?,reviewed_at=? WHERE id=?',(decision,reviewer,now,record_id))
        db.execute('INSERT INTO review_history(record_id,decision,reviewer,comment,reviewed_at) VALUES(?,?,?,?,?)',(record_id,decision,reviewer,comment,now))

def master(table):
    if table not in ('staff','vendors','assets','departments'):raise ValueError('Invalid master')
    with connect() as db: return [dict(x) for x in db.execute(f'SELECT * FROM {table}').fetchall()]

def notifications():
    with connect() as db: return [dict(x) for x in db.execute('SELECT * FROM notifications ORDER BY id DESC LIMIT 100').fetchall()]

def summary():
    with connect() as db:
        rows=db.execute('SELECT validation_status,review_status,COUNT(*) n FROM records GROUP BY 1,2').fetchall()
    return {'total':sum(r['n'] for r in rows),'pending':sum(r['n'] for r in rows if r['review_status']=='Pending Review'),'overdue':sum(r['n'] for r in rows if r['validation_status'] in ('Overdue','Expired')),'exceptions':sum(r['n'] for r in rows if r['validation_status']!='Checks Passed')}
