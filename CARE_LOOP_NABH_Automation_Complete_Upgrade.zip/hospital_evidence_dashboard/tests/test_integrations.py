import os,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from services.integrations import classify,ingest_cleaning_json,ingest_attachment,init_integrations
from sample_data.seed import initialise

def test_classify_training():
 assert classify('Staff training certificates','certificate.pdf')[0]=='EV-001'
 assert classify('No matching term','attachment.pdf')[0] is None

def test_cleaning_import_idempotence():
 initialise();init_integrations()
 event={'event_id':'QA-CLEANING-0001','timestamp':'2026-11-19T08:00:00+05:30','location':'ICU','status':'activity_detected'}
 first=ingest_cleaning_json([event]);second=ingest_cleaning_json([event])
 assert first['total']==1 and second['added']==0

def test_email_unclassified_staged():
 initialise();init_integrations()
 result=ingest_attachment('test-email','case-1','unknown.csv',b'foo,bar\n1,2\n',subject='unrecognised',sender='test@example.invalid')
 assert result['status'] in ('pending_review','duplicate')
