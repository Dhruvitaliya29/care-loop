"""Behavioral tests of the actual shared document intake and mocked providers."""
import io, os, sys, email
from pathlib import Path
from email.message import EmailMessage
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sample_data.seed import initialise, sample_path
from services.intake import migrate,intake_document,process_job,health
from services.connectors import sync_email,sync_laundry
from database.db import connect,records
from services.integrations import classify_confidence

def setup_module(_):
 initialise();migrate()

def test_signature_empty_invalid_and_unsupported():
 for i,(name,data) in enumerate([('fake.pdf',b'not pdf'),('empty.csv',b''),('evil.exe',b'MZfake'),('large.csv',b'x'*(12*1024*1024+1))]):
  if i==3:
   try:intake_document('email','bad'+str(i),name,data)
   except ValueError:pass
   else:assert False,'Oversize content must be rejected'
  else:
   r=intake_document('email','bad'+str(i),name,data)
   assert r['status']=='failed'
 with connect() as db:
  assert db.execute("SELECT COUNT(*) FROM intake_jobs WHERE status='Failed'").fetchone()[0]>=3

def test_email_classification_and_cross_source_hash_dedupe():
 src=sample_path('EV-028');body=src.read_bytes()
 first=intake_document('email','qa-msg-001',src.name,body,subject='Biomedical waste collection manifest')
 assert first['status']=='processed',first
 same=intake_document('telegram','qa-message-002',src.name,body,subject='Laundry')
 assert same['status']=='duplicate',same
 assert first['category']==same['category']
 with connect() as db:
  assert db.execute('SELECT COUNT(*) FROM intake_jobs WHERE content_sha256=(SELECT content_sha256 FROM intake_jobs WHERE id=?)',(first['intake_id'],)).fetchone()[0]>=2

def test_unclassified_attachment_reassignment():
 from sample_data.seed import sample_path
 src=sample_path('EV-001')
 data=src.read_bytes()
 r=intake_document('email','unknown-case-xyz','opaque.xlsx',data,subject='General attachment')
 # Extracted sheet columns can identify category; if not, review assignment must be available.
 assert r['status'] in ('pending_review','processed','duplicate')
 if r['status']=='pending_review':
  again=process_job(r['intake_id'],category_hint='EV-001')
  assert again['status']=='processed',again

def test_routing_ambiguity_and_notifications():
 cat,confidence,reason=classify_confidence('training certificate fire alarm','report.pdf')
 assert confidence<.72 or cat is not None
 with connect() as db:
  assert db.execute('SELECT COUNT(*) FROM intake_notifications').fetchone()[0]>0

def test_mock_imap_no_credentials(monkeypatch):
 monkeypatch.setenv('EMAIL_ENABLED','true')
 monkeypatch.delenv('EMAIL_HOST',raising=False)
 monkeypatch.delenv('CARELOOP_IMAP_HOST',raising=False)
 assert sync_email()['status']=='Not configured'

def test_mock_imap_message_processing(monkeypatch):
 src=sample_path('EV-009')
 msg=EmailMessage();msg['From']='authorized@example.org';msg['To']='receiving@example.org'
 msg['Subject']='Vendor AMC maintenance contract';msg['Message-ID']='<qa-imap-1@example.org>'
 msg.set_content('Maintenance contract enclosed')
 msg.add_attachment(src.read_bytes(),maintype='application',subtype='pdf',filename='amc_vendor.pdf')
 raw=msg.as_bytes()
 class FakeIMAP:
  def __init__(self,*a,**kw):pass
  def __enter__(self):return self
  def __exit__(self,*a):pass
  def login(self,*a):pass
  def select(self,*a,**kw):return ('OK',[b'1'])
  def response(self,*a):return ('UIDVALIDITY',[b'qa-231'])
  def uid(self,command,*args):
   if command=='search':return ('OK',[b'1'])
   return ('OK',[(b'1 (RFC822)',raw)])
 monkeypatch.setattr('services.connectors.imaplib.IMAP4_SSL',FakeIMAP)
 monkeypatch.setenv('EMAIL_ENABLED','true');monkeypatch.setenv('EMAIL_HOST','imap.example.invalid')
 monkeypatch.setenv('EMAIL_USERNAME','receiving@example.org');monkeypatch.setenv('EMAIL_PASSWORD','fake')
 monkeypatch.setenv('EMAIL_ALLOWED_SENDERS','authorized@example.org')
 a=sync_email();assert a['status']=='Connected',a
 b=sync_email();assert b['status']=='Connected' and b['processed']==0,b

def test_mock_telegram_allowlist_and_intake(monkeypatch):
 src=sample_path('EV-029');blob=src.read_bytes()
 monkeypatch.setenv('TELEGRAM_ENABLED','true');monkeypatch.setenv('TELEGRAM_BOT_TOKEN','fake-token')
 monkeypatch.setenv('TELEGRAM_ALLOWED_CHAT_IDS','10022')
 with connect() as db:db.execute("DELETE FROM integration_state WHERE name='telegram_offset'")
 sent=[]
 def fake(method,token,fields=None):
  if method=='getMe':return {'id':123}
  if method=='getUpdates':return [
   {'update_id':41,'message':{'message_id':10,'chat':{'id':999},'document':{'file_id':'bad','file_name':'linen.xlsx'}}},
   {'update_id':42,'message':{'message_id':11,'chat':{'id':10022},'caption':'Laundry linen receipt','document':{'file_id':'good','file_name':'linen_register.xlsx','file_size':len(blob)}}}]
  if method=='getFile':return {'file_path':'path/to/fake'}
  if method=='sendMessage':sent.append(fields['text']);return {'message_id':12}
  raise ValueError(method)
 class FakeResponse:
  def __enter__(self):return self
  def __exit__(self,*a):pass
  def read(self,n):return blob
 monkeypatch.setattr('services.connectors.telegram_request',fake)
 monkeypatch.setattr('services.connectors.urllib.request.urlopen',lambda *a,**kw:FakeResponse())
 r=sync_laundry()
 assert r['status']=='Connected' and r['unauthorized']==1,r
 assert r['processed']+r['duplicate']+r['pending_review']>=1,r
 assert len(sent)==1

def test_health_and_log_records():
 with connect() as db:
  assert db.execute("SELECT COUNT(*) FROM integration_health").fetchone()[0]>=2
  assert db.execute("SELECT COUNT(*) FROM integration_logs").fetchone()[0]>=1
