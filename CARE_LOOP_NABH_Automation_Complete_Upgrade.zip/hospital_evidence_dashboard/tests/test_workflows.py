import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from config.categories import CAT,SCHEMAS
from sample_data.seed import initialise,SAMPLES,sample_path
from services.workflows import process_sample
from services.validation import validate
from services.document_parser import parse_document
from database.db import records,summary,review

def test_catalogue_all_sixteen():
    assert len(CAT)==16
    assert sum(x['candidate']=='Yes' for x in CAT.values())==6
    assert all(len(SCHEMAS[x])>=6 for x in CAT)

def test_all_sample_files_exist_and_parse():
    initialise()
    for cat in CAT:
        p=sample_path(cat)
        assert p.exists(),cat
        items=parse_document(p.name,p.read_bytes(),cat)
        assert len(items)>0,cat
        assert set(items[0]).intersection(SCHEMAS[cat]),cat

def test_all_workflows_persist_and_duplicate_is_stable():
    initialise()
    for cat in CAT:
        result=process_sample(cat)
        assert result,cat
        assert records(cat),cat
    before=summary()['total']
    for cat in CAT:process_sample(cat)
    assert summary()['total']==before

def test_expected_exceptions():
    initialise()
    assert validate('EV-027',SAMPLES['EV-027'][0])[0]=='Action Required'
    assert 'Linen quantity discrepancy' in validate('EV-029',SAMPLES['EV-029'][0])[1]
    assert validate('EV-020',SAMPLES['EV-020'][0])[0]=='Expired'
    assert validate('EV-001',SAMPLES['EV-001'][0])[0]=='Checks Passed'

def test_review_audit():
    initialise(); rid=process_sample('EV-001')[0]['id']
    review(rid,'Approved','SVH-EMP-006','Demo document checked')
    assert next(x for x in records('EV-001') if x['id']==rid)['review_status']=='Approved'

def test_reports_and_reupload():
    from services.report_service import csv_bytes,excel_bytes
    from services.workflows import process_bytes
    from io import BytesIO
    import pandas as pd
    initialise()
    src=sample_path('EV-028')
    processed=process_bytes('EV-028',src.name,src.read_bytes(),'upload')
    assert len(processed)==1
    csvtext=csv_bytes('EV-028').decode('utf-8-sig')
    assert 'manifest_number' in csvtext
    assert 'SVH-BMW-MNF-02618' in csvtext
    df=pd.read_excel(BytesIO(excel_bytes('EV-028')),skiprows=2)
    assert not df.empty
    assert df.iloc[0]['evidence_id']=='EV-028'

def test_original_source_traceability_and_notifications():
    from database.db import notifications,connect
    initialise()
    row=process_sample('EV-029')[0]
    assert row['issues']
    with connect() as db:
        source=db.execute('SELECT d.sha256,d.stored_path FROM documents d JOIN records r ON r.document_id=d.id WHERE r.id=?',(row['id'],)).fetchone()
        assert source and Path(source['stored_path']).exists()
    assert any(n['record_id']==row['id'] for n in notifications())
