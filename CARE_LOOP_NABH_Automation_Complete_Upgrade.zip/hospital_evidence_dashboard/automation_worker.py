"""Independent single-process background worker. Never launch from Streamlit reruns."""
import logging,os,time,signal
from pathlib import Path
from sample_data.seed import initialise
from services.intake import migrate
from services.connectors import sync_email,sync_laundry
from database.db import DATA_DIR
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
STOP=False

def stop(*_):
 global STOP
 STOP=True

def run():
 initialise();migrate()
 import sys
 # Unix flock is used for Render; Windows deployments should start only one worker manually.
 lock=None
 if os.name!='nt':
  import fcntl
  lock=open(DATA_DIR/'automation_worker.lock','w')
  try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise RuntimeError('Another automation worker is already active')
 signal.signal(signal.SIGTERM,stop)
 signal.signal(signal.SIGINT,stop)
 interval=max(30,int(os.getenv('CARELOOP_POLL_SECONDS','120')))
 logging.info('CARE LOOP background intake worker started')
 while not STOP:
  for name,task in (('email',sync_email),('telegram',sync_laundry)):
   if STOP:break
   try:
    result=task()
    logging.info('%s status=%s count=%s',name,result.get('status'),result.get('processed',0))
   except Exception as exc:logging.error('%s failed: %s',name,type(exc).__name__)
  for _ in range(interval):
   if STOP:break
   time.sleep(1)
 if lock:lock.close()
 logging.info('CARE LOOP worker stopped')
if __name__=='__main__':run()
