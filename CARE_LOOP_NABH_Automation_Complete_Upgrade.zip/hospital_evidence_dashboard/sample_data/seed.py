"""One fictional hospital and connected primary keys across all sixteen demos."""
from pathlib import Path
from database.db import init_db,insert_master
BASE=Path(__file__).parent
HOSPITAL='Sahyadri Valley Multispeciality Hospital'
DEPARTMENTS=['ICU','Emergency','OPD','IPD','OT','Laboratory','Radiology','Pharmacy','Housekeeping','Engineering','Quality','Biomedical Waste','Laundry']
STAFF=[
('SVH-EMP-001','Aarav Mehta','ICU','Staff Nurse'),('SVH-EMP-002','Neha Desai','OT','Nursing Supervisor'),('SVH-EMP-003','Rohan Shah','Engineering','Biomedical Engineer'),('SVH-EMP-004','Kavya Patel','Housekeeping','Housekeeping Supervisor'),('SVH-EMP-005','Imran Qureshi','Biomedical Waste','BMW Officer'),('SVH-EMP-006','Priya Joshi','Quality','Quality Manager'),('SVH-EMP-007','Devansh Trivedi','Emergency','Medical Officer'),('SVH-EMP-008','Farah Khan','Laundry','Laundry Supervisor'),('SVH-EMP-009','Ishita Nair','ICU','Staff Nurse'),('SVH-EMP-010','Harsh Vyas','Engineering','Fire Safety Officer')]
VENDORS=[('SVH-VND-001','Navjyot Facility Services (Fictional)','Fire safety and alarm'),('SVH-VND-002','Astra Engineering Services (Fictional)','Generator / lift AMC'),('SVH-VND-003','MedPipe Systems (Fictional)','Medical gas service'),('SVH-VND-004','GreenShield Hygiene (Fictional)','Pest control'),('SVH-VND-005','EcoCycle CBWTF (Fictional)','Biomedical waste collection')]
ASSETS=[('SVH-FE-001','ABC Powder Fire Extinguisher 6 kg','Emergency','SVH-VND-001','Emergency East Corridor',90),('SVH-FA-001','Addressable Fire Alarm Panel','Engineering','SVH-VND-001','Fire Control Room',30),('SVH-DG-001','250 kVA Diesel Generator','Engineering','SVH-VND-002','DG Yard',90),('SVH-MG-001','Medical Oxygen Manifold','ICU','SVH-VND-003','MGPS Plant Room',30),('SVH-LF-001','Patient Lift L1','Engineering','SVH-VND-002','North Block',30),('SVH-AH-001','ICU Air Handling Unit','ICU','SVH-VND-002','ICU Plant Room',60)]

def initialise():
    init_db()
    insert_master('departments',[dict(id=x.replace(' ','-').upper(),name=x) for x in DEPARTMENTS])
    insert_master('staff',[dict(zip(('id','name','department','designation'),x)) for x in STAFF])
    insert_master('vendors',[dict(zip(('id','name','service'),x)) for x in VENDORS])
    insert_master('assets',[dict(zip(('id','name','department','vendor_id','location','frequency_days'),x)) for x in ASSETS])
    from config.categories import CAT,REFERENCE
    from database.db import connect
    with connect() as db:
        for category in CAT:
            db.execute('INSERT OR IGNORE INTO rule_definitions(id,category_id,classification,description,source_reference,threshold) VALUES(?,?,?,?,?,?)',(
                'POC-'+category,category,'Configurable hospital-specific rule / demonstration assumption',
                'Document field completeness, master key matching and exception checks; frequency/thresholds are not automatically statutory',
                REFERENCE[category],'From provided document or configurable POC policy'))

def sample_path(category):
    names={'EV-001':'training_attendance.xlsx','EV-002':'professional_licence.pdf','EV-008':'capa_closure.pdf','EV-009':'vendor_amc.pdf','EV-013':'extinguisher_inspection.pdf','EV-016':'fire_alarm_test.pdf','EV-018':'generator_maintenance.xlsx','EV-019':'medical_gas_maintenance.pdf','EV-020':'lift_certificate.pdf','EV-022':'pest_control_service.pdf','EV-023':'preventive_maintenance.xlsx','EV-025':'daily_cleaning.xlsx','EV-027':'bmw_segregation.xlsx','EV-028':'bmw_manifest.pdf','EV-029':'linen_register.xlsx','EV-038':'fictional_fall_incident.pdf'}
    return BASE/names[category]

SAMPLES={
'EV-001':[
{'employee_id':'SVH-EMP-001','employee_name':'Aarav Mehta','training_topic':'Biomedical waste segregation','training_date':'09-10-2026','trainer':'Imran Qureshi','certificate_number':'SVH-TR-2026-104','competency_status':'Assessed'},
{'employee_id':'SVH-EMP-009','employee_name':'Ishita Nair','training_topic':'Fire safety drill','training_date':'02-11-2026','trainer':'Harsh Vyas','certificate_number':'','competency_status':'Pending'}],
'EV-002':[{'employee_id':'SVH-EMP-001','employee_name':'Aarav Mehta','qualification':'B.Sc. Nursing','council':'Fictional Nursing Council - Demo','registration_number':'DEMO-GNC-51092','issue_date':'14-06-2022','expiry_date':'14-06-2027'}],
'EV-008':[{'capa_id':'SVH-CAPA-026','source_evidence_id':'EV-027','finding':'Red stream waste mixed in yellow container in OT','root_cause':'Segregation signage absent','action_owner':'SVH-EMP-005','due_date':'05-11-2026','corrective_action':'Replace colour-coded signage and retrain OT shift','effectiveness_status':'Pending'}],
'EV-009':[{'contract_number':'SVH-AMC-2026-009','vendor_id':'SVH-VND-001','vendor_name':'Navjyot Facility Services (Fictional)','asset_id':'SVH-FE-001','start_date':'01-01-2026','end_date':'31-12-2026','scope':'Fire extinguisher inspection and service'}],
'EV-013':[{'asset_id':'SVH-FE-001','inspection_date':'12-08-2026','service_date':'12-08-2026','next_due_date':'10-11-2026','vendor_id':'SVH-VND-001','pressure_status':'OK','seal_status':'Broken'}],
'EV-016':[{'asset_id':'SVH-FA-001','test_date':'07-11-2026','next_due_date':'07-12-2026','vendor_id':'SVH-VND-001','detector_test':'Pass','call_point_test':'Fail','observations':'Call point in east corridor not responding'}],
'EV-018':[{'asset_id':'SVH-DG-001','service_date':'10-09-2026','next_due_date':'09-12-2026','vendor_id':'SVH-VND-002','engine_hours':'1842','frequency_hz':'50.0','result':'Pass'}],
'EV-019':[{'asset_id':'SVH-MG-001','inspection_date':'16-11-2026','next_due_date':'16-12-2026','vendor_id':'SVH-VND-003','pressure_bar':'4.2','alarm_result':'Pass','observations':'Line pressure in demonstration range; engineer to verify'}],
'EV-020':[{'asset_id':'SVH-LF-001','certificate_number':'DEMO-LIFT-GJ-2025-071','inspection_date':'01-09-2025','valid_until':'01-09-2026','vendor_id':'SVH-VND-002','observations':'Fictional certificate: issuer must be physically verified'}],
'EV-022':[{'service_id':'SVH-PC-2026-045','vendor_id':'SVH-VND-004','location':'Kitchen and waste holding room','visit_date':'10-11-2026','next_visit':'10-12-2026','treatment':'Gel bait / trapping (fictional)','observation':'No active pest observed'}],
'EV-023':[{'asset_id':'SVH-AH-001','department':'ICU','last_service_date':'01-09-2026','frequency_days':'60','next_due_date':'31-10-2026','assigned_owner':'SVH-EMP-003','status':'Pending'},
{'asset_id':'SVH-DG-001','department':'Engineering','last_service_date':'10-09-2026','frequency_days':'90','next_due_date':'09-12-2026','assigned_owner':'SVH-EMP-003','status':'Scheduled'}],
'EV-025':[{'location':'ICU Bed Bay 2','date':'17-11-2026','time':'08:30','employee_id':'SVH-EMP-004','procedure':'High touch surface disinfection','completion_status':'Incomplete','supervisor_id':'SVH-EMP-004'},
{'location':'OPD Waiting Area','date':'17-11-2026','time':'09:10','employee_id':'SVH-EMP-004','procedure':'Floor wet mopping','completion_status':'Completed','supervisor_id':'SVH-EMP-004'}],
'EV-027':[{'inspection_id':'SVH-BMW-AUD-076','department':'OT','inspection_date':'03-11-2026','inspector_id':'SVH-EMP-005','yellow_check':'Fail','red_check':'Pass','white_check':'Pass','blue_check':'Pass'}],
'EV-028':[{'manifest_number':'SVH-BMW-MNF-02618','vendor_id':'SVH-VND-005','collection_date':'17-11-2026','waste_category':'Yellow','weight_kg':'18.4','expected_weight_kg':'19.1','barcode':'DEMO-BMW-Y-02618','vehicle_number':'DEMO-GJ01-BW-1234','handover_by':'SVH-EMP-005'}],
'EV-029':[{'batch_id':'SVH-LIN-2026-108','department':'ICU','collection_date':'17-11-2026','linen_type':'Bedsheets','sent_qty':'80','returned_qty':'78','process_status':'Returned with discrepancy'}],
'EV-038':[{'incident_id':'SVH-INC-2026-014','incident_date':'16-11-2026','department':'IPD','severity':'Minor (fictional)','immediate_action':'Nurse examination and shift supervisor informed','investigation_owner':'SVH-EMP-006','investigation_status':'In Progress','capa_id':'SVH-CAPA-027'}]
}
