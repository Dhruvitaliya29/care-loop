"""Creates real sample XLSX using artifact_tool and text-based PDF via ReportLab."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
FONT_PATH=Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
if FONT_PATH.exists():
    pdfmetrics.registerFont(TTFont("DejaVu",str(FONT_PATH)))
from artifact_tool import Workbook,SpreadsheetFile
from config.categories import CAT,SCHEMAS,LABEL
from sample_data.seed import SAMPLES,sample_path,HOSPITAL


def pdf_document(path, category, data):
    c=canvas.Canvas(str(path),pagesize=A4)
    w,h=A4
    c.setFillColor(HexColor('#123457'));c.rect(0,h-105,w,105,fill=1,stroke=0)
    c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',15);c.drawString(36,h-48,HOSPITAL)
    c.setFont('Helvetica',10);c.drawString(36,h-70,'EVIDENCE MANAGEMENT | FICTIONAL POC')
    c.setFont('DejaVu' if FONT_PATH.exists() else 'Helvetica-Bold',10);c.setFillColor(HexColor('#a32222'));c.drawString(36,h-128,LABEL if FONT_PATH.exists() else 'DEMO DATA - NOT AN ACTUAL HOSPITAL RECORD')
    c.setFillColor(HexColor('#123457'));c.setFont('Helvetica-Bold',12);c.drawString(36,h-155,category+' | '+CAT[category]['name'])
    y=h-195;c.setFont('Helvetica',10)
    for key,val in data.items():
        # Using snake_case labels makes PDF extraction deterministic and reusable.
        label=key.replace('_',' ').title()
        line=f'{label}: {val}'
        if len(line)>90:
            line=line[:89]+'...'
        c.setFillColor(HexColor('#12283e'));c.drawString(42,y,line);y-=25
        if y<85:c.showPage();y=h-65
    c.setStrokeColor(HexColor('#c6d4e0'));c.line(40,y-20,w-40,y-20)
    c.setFillColor(HexColor('#567086'));c.setFont('Helvetica',9)
    c.drawString(42,y-45,'Prepared by: [Fictional Staff Signature]')
    c.drawString(300,y-45,'Verified by: [Pending Human Review]')
    c.drawString(42,38,'This document is a generated demonstration sample. No regulatory approval is asserted.')
    c.save()

def xlsx_document(path,category,items):
    wb=Workbook.create();sh=wb.worksheets.add('Evidence Register')
    fields=list(SCHEMAS[category]); extras=[k for d in items for k in d if k not in fields]
    fields+=list(dict.fromkeys(extras))
    # header row is row 1 so upload parser reads field names as the actual headers.
    data=[fields]+[[d.get(f,'') for f in fields] for d in items]
    sh.get_range_by_indexes(0,0,len(data),len(fields)).values=data
    sh.get_range_by_indexes(0,0,1,len(fields)).format.fill='#123457'
    sh.get_range_by_indexes(0,0,1,len(fields)).format.font.color='#FFFFFF'
    sh.get_range_by_indexes(0,0,1,len(fields)).format.font.bold=True
    sh.get_range_by_indexes(0,0,len(data),len(fields)).format.column_width=21
    sh.freeze_panes.freeze_rows(1)
    note=wb.worksheets.add('DEMO NOTICE')
    note.get_range('A1').values=[[LABEL]]
    note.get_range('A2').values=[[HOSPITAL]]
    note.get_range('A3').values=[['Fictional sample; reviewer signoffs and compliance claims are NOT real.']]
    note.get_range('A1:C1').format.fill='#123457';note.get_range('A1:C1').format.font.color='#FFFFFF'
    note.get_range('A1:C3').format.column_width=37
    SpreadsheetFile.export_xlsx(wb).save(str(path))

def generate():
    for category,items in SAMPLES.items():
        path=sample_path(category)
        if path.suffix=='.xlsx':xlsx_document(path,category,items)
        else:pdf_document(path,category,items[0])
    print('Generated 16 sample documents')
if __name__=='__main__':generate()
